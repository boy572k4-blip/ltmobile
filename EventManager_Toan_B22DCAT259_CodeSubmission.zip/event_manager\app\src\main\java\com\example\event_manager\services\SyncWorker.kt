package com.example.event_manager.services

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.Constraints
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.example.event_manager.data.EventDatabase
import com.example.event_manager.data.remote.EventApiService
import com.example.event_manager.data.remote.EventDto
import com.example.event_manager.util.SecurityHelper
import kotlinx.coroutines.flow.first
import java.util.concurrent.TimeUnit

/**
 * Lớp Đồng Bộ Dữ Liệu Nền Offline-First (SyncWorker).
 * Kế thừa từ CoroutineWorker của Android Jetpack WorkManager.
 * Cho phép chạy các tác vụ đồng bộ hóa bất đồng bộ dưới nền, đảm bảo dữ liệu cục bộ SQLite
 * và dữ liệu đám mây luôn được nhất quán mà không gây gián đoạn hay đơ lag giao diện người dùng.
 */
class SyncWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    /**
     * Phương thức xử lý tác vụ đồng bộ nền bất đồng bộ chính.
     * Tự động lấy danh sách dữ liệu từ Room Database cục bộ và đẩy đồng bộ lên Cloud Server REST API.
     * @return Result.success() nếu đồng bộ thành công, Result.retry() để thử lại sau khi lỗi mạng,
     * hoặc Result.failure() nếu gặp lỗi không thể khắc phục.
     */
    override suspend fun doWork(): Result {
        Log.d("SyncWorker", "Bắt đầu tiến trình đồng bộ dữ liệu nền tự động...")

        val context = applicationContext
        
        // Khởi tạo Database Room nội bộ
        val db = EventDatabase.build(context)
        
        // Khởi tạo Retrofit API Service kết nối mạng
        val api = EventApiService.create()

        // Truy xuất Token JWT bảo mật đã được mã hóa lưu trong EncryptedSharedPreferences
        val token = SecurityHelper.getAccessToken(context)
        if (token == null) {
            Log.w("SyncWorker", "Không tìm thấy token đăng nhập hợp lệ. Hủy tác vụ đồng bộ nền.")
            return Result.failure()
        }

        try {
            // =================================================================
            // 1. ĐỒNG BỘ XUÔI (LOCAL -> CLOUD): Đẩy dữ liệu tạo ngoại tuyến lên Server
            // =================================================================
            
            // Đọc toàn bộ danh sách sự kiện từ Room Database (dạng đồng bộ bất đồng bộ Flow)
            val localEvents = db.eventDao().observeEvents().first()
            Log.d("SyncWorker", "Đang quét dữ liệu: tìm thấy ${localEvents.size} sự kiện cục bộ")
            
            // Lặp qua từng sự kiện để tiến hành đồng bộ
            for (event in localEvents) {
                // Mapping EventSummary local sang EventDto gửi lên REST API.
                // Trong production nên bổ sung serverId/syncStatus để tránh tạo trùng.
                val dto = EventDto(
                    eventId = event.eventId,
                    eventName = event.eventName,
                    startDatetime = event.startDatetime,
                    endDatetime = event.endDatetime,
                    description = event.description,
                    status = event.status.name,
                    typeId = 1, // Mã ID loại sự kiện tương ứng
                    locationId = 1, // Mã ID địa điểm tương ứng
                    expectedGuests = 100
                )
                
                // Gọi API ngoài đính kèm Token Bearer JWT để đẩy sự kiện lên máy chủ đám mây
                val response = api.createEvent("Bearer $token", dto)
                if (response.isSuccessful) {
                    Log.d("SyncWorker", "Đồng bộ thành công sự kiện lên Cloud: ${event.eventName}")
                } else {
                    Log.e("SyncWorker", "Lỗi đồng bộ sự kiện ${event.eventName}: Code ${response.code()} - ${response.message()}")
                }
            }

            // =================================================================
            // 2. ĐỒNG BỘ NGƯỢC (CLOUD -> LOCAL): Tải dữ liệu mới từ máy chủ về máy
            // =================================================================
            
            // Gọi API mạng tải toàn bộ danh sách sự kiện mới nhất trên server đám mây
            val response = api.getEvents("Bearer $token")
            if (response.isSuccessful) {
                val cloudEvents = response.body() ?: emptyList()
                Log.d("SyncWorker", "Đã tải xuống thành công ${cloudEvents.size} sự kiện mới nhất từ Cloud Server")
                // TODO: Cập nhật đồng bộ ngược vào Room DB cục bộ.
                // Cần mapping EventDto -> EventEntity/LocationEntity/EventTypeEntity và xử lý conflict.
            }

            return Result.success()
        } catch (e: Exception) {
            Log.e("SyncWorker", "Lỗi kết nối mạng xảy ra trong quá trình đồng bộ dữ liệu: ${e.message}", e)
            
            // Trả về retry để WorkManager tự động lập lịch chạy lại tác vụ khi thiết bị kết nối mạng tốt hơn
            return Result.retry() 
        }
    }

    companion object {
        // Nhãn định danh duy nhất cho tác vụ đồng bộ nền của ứng dụng
        private const val SYNC_TAG = "event_sync_work"

        /**
         * Hàm khởi tạo và lập lịch cho tác vụ đồng bộ nền chạy định kỳ.
         * Tác vụ sẽ tự động kích hoạt mỗi 2 giờ một lần dưới sự quản lý của hệ điều hành Android.
         * @param context Ngữ cảnh ứng dụng.
         */
        fun enqueuePeriodicSync(context: Context) {
            // Thiết lập các ràng buộc (Constraints) bảo vệ tài nguyên thiết bị di động
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED) // Ràng buộc 1: Chỉ chạy khi điện thoại CÓ MẠNG Internet
                .setRequiresBatteryNotLow(true) // Ràng buộc 2: Chỉ chạy khi dung lượng PIN không quá yếu
                .build()

            // Tạo yêu cầu công việc chạy định kỳ mỗi 2 giờ
            val syncRequest = PeriodicWorkRequestBuilder<SyncWorker>(2, TimeUnit.HOURS)
                .setConstraints(constraints) // Gắn ràng buộc bảo vệ pin và mạng
                .addTag(SYNC_TAG) // Gắn tag định danh tác vụ
                .build()

            // Đăng ký công việc vào WorkManager hệ thống
            // Chế độ KEEP đảm bảo nếu tác vụ đã được lập lịch thì giữ nguyên, tránh tạo trùng lặp tiến trình
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                SYNC_TAG,
                androidx.work.ExistingPeriodicWorkPolicy.KEEP,
                syncRequest
            )
            Log.d("SyncWorker", "Đã đăng ký tác vụ đồng bộ dữ liệu chạy ngầm 2 giờ/lần thành công vào WorkManager.")
        }
    }
}
