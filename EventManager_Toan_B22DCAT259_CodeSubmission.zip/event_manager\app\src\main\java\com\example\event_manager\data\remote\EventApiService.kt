package com.example.event_manager.data.remote

import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import java.util.concurrent.TimeUnit

// =============================================================================
// DATA TRANSFER OBJECTS (DTOs) - ĐỐI TƯỢNG TRUYỀN TẢI DỮ LIỆU QUA MẠNG
// =============================================================================

/**
 * DTO đại diện cho yêu cầu Đăng nhập của người dùng.
 * @property email Địa chỉ email tài khoản người dùng đăng nhập.
 * @property password Mật khẩu tài khoản (dạng nguyên bản, sẽ được mã hóa HTTPS).
 */
data class LoginRequest(
    val email: String,
    val password: String
)

/**
 * DTO đại diện cho phản hồi từ máy chủ khi Đăng nhập thành công.
 * @property accessToken Chuỗi token xác thực JWT ngắn hạn (dùng để đính kèm Header Authorization).
 * @property refreshToken Chuỗi token dùng để cấp lại Access Token mới khi hết hạn.
 * @property userId Mã ID định danh duy nhất của người dùng trên Cloud Server.
 * @property fullName Họ và tên đầy đủ của người dùng.
 * @property role Quyền hạn của người dùng (Ví dụ: ADMIN, ORGANIZER).
 */
data class LoginResponse(
    val accessToken: String,
    val refreshToken: String,
    val userId: Int,
    val fullName: String,
    val role: String
)

/**
 * DTO đại diện cho yêu cầu Đăng ký tài khoản mới.
 * @property fullName Họ và tên của người đăng ký.
 * @property email Email đăng ký tài khoản (duy nhất).
 * @property phone Số điện thoại liên lạc.
 * @property password_hash Mật khẩu đã được băm an toàn ở phía client (hoặc chuỗi mật khẩu thô).
 * @property roleId ID nhóm quyền đăng ký (Mặc định là 2 - ORGANIZER).
 */
data class RegisterRequest(
    val fullName: String,
    val email: String,
    val phone: String,
    val password_hash: String,
    val roleId: Int = 2
)

/**
 * DTO đại diện cho phản hồi từ máy chủ khi đăng ký tài khoản thành công.
 * @property message Thông điệp phản hồi từ máy chủ (Ví dụ: "Đăng ký thành công!").
 * @property userId ID duy nhất vừa được cấp cho tài khoản mới.
 */
data class RegisterResponse(
    val message: String,
    val userId: Int
)

/**
 * DTO mô tả chi tiết thực thể Sự kiện phục vụ truyền tải dữ liệu qua REST API.
 * @property eventId Mã định danh sự kiện.
 * @property eventName Tên sự kiện tổ chức.
 * @property startDatetime Thời gian bắt đầu sự kiện (dạng Epoch Milliseconds).
 * @property endDatetime Thời gian kết thúc sự kiện (dạng Epoch Milliseconds).
 * @property description Mô tả chi tiết nội dung sự kiện.
 * @property status Trạng thái sự kiện (PLANNING, ACTIVE, COMPLETED, CANCELLED).
 * @property typeId Mã ID phân loại sự kiện.
 * @property locationId Mã ID địa điểm tổ chức.
 * @property expectedGuests Số lượng khách tham gia dự kiến.
 */
data class EventDto(
    val eventId: Int,
    val eventName: String,
    val startDatetime: Long,
    val endDatetime: Long,
    val description: String,
    val status: String,
    val typeId: Int,
    val locationId: Int,
    val expectedGuests: Int
)

/**
 * DTO đại diện cho phản hồi khi khởi tạo Sự kiện thành công trên máy chủ.
 * @property message Thông báo kết quả từ máy chủ.
 * @property eventId ID duy nhất của sự kiện vừa được tạo trên đám mây.
 */
data class CreateEventResponse(
    val message: String,
    val eventId: Int
)

/**
 * DTO gửi yêu cầu phản hồi RSVP của khách mời tham dự sự kiện.
 * @property status Trạng thái xác nhận tham gia (ACCEPTED, DECLINED, MAYBE).
 */
data class RsvpRequest(
    val status: String
)

/**
 * DTO phản hồi kết quả cập nhật RSVP từ máy chủ.
 * @property message Thông điệp phản hồi.
 * @property newStatus Trạng thái phản hồi mới đã được ghi nhận.
 */
data class RsvpResponse(
    val message: String,
    val newStatus: String
)

// =============================================================================
// RETROFIT API INTERFACE - ĐỊNH NGHĨA CÁC ĐẦU CỔNG KẾT NỐI API ĐÁM MÂY
// =============================================================================

/**
 * Giao diện kết nối mạng sử dụng thư viện Retrofit.
 * Chứa tất cả các khai báo API gọi ngoài kết nối tới Cloud Server Backend.
 */
interface EventApiService {

    /**
     * API Đăng nhập hệ thống.
     * Gửi Email và Mật khẩu lên Server để nhận lại Token JWT.
     * @param request Đối tượng chứa Email và Mật khẩu.
     * @return Phản hồi HTTP chứa Token JWT và thông tin cơ bản của User.
     */
    @POST("api/auth/login")
    suspend fun login(@Body request: LoginRequest): Response<LoginResponse>

    /**
     * API Đăng ký tài khoản người dùng mới.
     * @param request Đối tượng chứa thông tin đăng ký tài khoản.
     * @return Phản hồi HTTP thông báo kết quả đăng ký thành công.
     */
    @POST("api/auth/register")
    suspend fun register(@Body request: RegisterRequest): Response<RegisterResponse>

    /**
     * API Lấy danh sách toàn bộ sự kiện từ Cloud Server.
     * @param token Chuỗi Token xác thực dạng "Bearer <jwt_token>" đính kèm trong Header.
     * @return Danh sách các sự kiện được lưu trữ trên Server.
     */
    @GET("api/events")
    suspend fun getEvents(@Header("Authorization") token: String): Response<List<EventDto>>

    /**
     * API Đẩy một sự kiện được tạo offline từ thiết bị di động lên Cloud Server.
     * @param token Chuỗi Token xác thực dạng "Bearer <jwt_token>" đính kèm trong Header.
     * @param event Đối tượng sự kiện chi tiết được truyền đi.
     * @return Thông báo kết quả và ID sự kiện được cấp trên server.
     */
    @POST("api/events")
    suspend fun createEvent(
        @Header("Authorization") token: String,
        @Body event: EventDto
    ): Response<CreateEventResponse>

    /**
     * API Xác nhận tham dự sự kiện (RSVP) thông qua liên kết Deep Link cá nhân.
     * API này cho phép khách mời phản hồi trạng thái tham gia nhanh từ liên kết thư mời gửi đến họ.
     * @param rsvpToken Chuỗi token bảo mật định danh duy nhất đính kèm ở đường link.
     * @param request Đối tượng chứa trạng thái xác nhận tham gia mới.
     * @return Kết quả ghi nhận trạng thái từ máy chủ.
     */
    @POST("api/invitations/{token}/rsvp")
    suspend fun submitRsvp(
        @Path("token") rsvpToken: String,
        @Body request: RsvpRequest
    ): Response<RsvpResponse>

    companion object {
        // Địa chỉ máy chủ Cloud Backend API thực tế phục vụ đồng bộ dữ liệu
        private const val BASE_URL = "https://api.eventmanager.io/"

        /**
         * Hàm khởi tạo và cấu hình Retrofit Service Client.
         * Tích hợp OkHttpClient, chế độ Log đường truyền, và thiết lập Timeout kết nối an toàn.
         */
        fun create(): EventApiService {
            // Khởi tạo HttpLoggingInterceptor để ghi nhận chi tiết dữ liệu Request/Response ra logcat hỗ trợ debug
            val logger = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            }

            // Cấu hình OkHttpClient đi kèm thời gian chờ Timeout kết nối là 30 giây để xử lý đường truyền kém
            val client = OkHttpClient.Builder()
                .addInterceptor(logger)
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .build()

            // Tạo đối tượng Retrofit, sử dụng Gson làm bộ phân tách JSON sang Object
            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(EventApiService::class.java)
        }
    }
}
