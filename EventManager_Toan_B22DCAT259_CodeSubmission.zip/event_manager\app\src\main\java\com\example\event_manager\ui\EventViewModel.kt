package com.example.event_manager.ui

import android.app.Activity
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.event_manager.data.AppLanguage
import com.example.event_manager.data.EventDatabase
import com.example.event_manager.data.EventRepository
import com.example.event_manager.data.EventSummary
import com.example.event_manager.data.GuestEntity
import com.example.event_manager.data.InvitationChannel
import com.example.event_manager.data.InvitationStatus
import com.example.event_manager.util.mapsLink
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * ViewModel cho toàn bộ màn hình Event Manager.
 *
 * ViewModel expose dữ liệu UI bằng StateFlow để Jetpack Compose collect và tự
 * recomposition khi Room thay đổi. Các thao tác ghi dữ liệu đều chạy trong
 * `viewModelScope.launch`, giúp không block main thread.
 */
class EventViewModel(
    private val repository: EventRepository
) : ViewModel() {

    val language = mutableStateOf(AppLanguage.VI)
    val selectedEventId = mutableStateOf<Int?>(null)

    val events = repository.observeEvents()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val guests = repository.observeGuests()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val eventTypes = repository.observeEventTypes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val dashboard = repository.observeDashboard()
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5_000),
            com.example.event_manager.data.EventDashboard(0, 0, 0, 0, 0, 0.0)
        )

    init {
        // Seed dữ liệu demo khi app chạy lần đầu để người dùng có thể kiểm thử ngay.
        viewModelScope.launch {
            repository.ensureSeedData()
        }
    }

    /** Trả về sự kiện đang được chọn, fallback về sự kiện đầu tiên nếu chưa chọn. */
    fun currentEvent(events: List<EventSummary>): EventSummary? =
        events.firstOrNull { it.eventId == selectedEventId.value } ?: events.firstOrNull()

    fun selectEvent(eventId: Int) {
        selectedEventId.value = eventId
    }

    fun toggleLanguage() {
        language.value = if (language.value == AppLanguage.VI) AppLanguage.EN else AppLanguage.VI
    }

    /** Tạo sự kiện mới từ form UI và tự sinh Google Maps link từ tọa độ/địa chỉ. */
    fun createEvent(
        title: String,
        description: String,
        start: Long,
        end: Long,
        typeId: Int,
        locationName: String,
        address: String,
        lat: Double?,
        lng: Double?
    ) {
        viewModelScope.launch {
            repository.createEvent(
                title = title,
                description = description,
                start = start,
                end = end,
                typeId = typeId,
                locationName = locationName,
                address = address,
                mapsLink = mapsLink(lat, lng, address),
                lat = lat,
                lng = lng
            )
        }
    }

    fun addGuest(name: String, email: String, phone: String) {
        viewModelScope.launch { repository.createGuest(name, email, phone) }
    }

    /** Tạo nội dung lời mời từ thông tin event/guest rồi chuyển xuống Repository để lưu. */
    fun sendInvitation(event: EventSummary, guest: GuestEntity, channel: InvitationChannel) {
        val body = com.example.event_manager.util.buildInvitationText(event, guest)
        viewModelScope.launch {
            repository.sendInvitation(
                eventId = event.eventId,
                guestId = guest.guestId,
                channel = channel,
                invitationText = body,
                mapsLink = event.googleMapsLink
            )
        }
    }

    fun updateInvitation(invitationId: Int, status: InvitationStatus) {
        viewModelScope.launch { repository.updateInvitationStatus(invitationId, status) }
    }

    fun updateCheckIn(invitationId: Int, checkedIn: Boolean) {
        viewModelScope.launch { repository.updateCheckInStatus(invitationId, checkedIn) }
    }

    fun sendEventReminder(eventId: Int, invitationId: Int) {
        viewModelScope.launch { repository.sendEventReminder(eventId, invitationId) }
    }

    fun completeEvent(eventId: Int) {
        viewModelScope.launch { repository.completeEvent(eventId) }
    }

    fun sendSurvey(eventId: Int) {
        viewModelScope.launch { repository.sendSurvey(eventId) }
    }

    fun addTask(eventId: Int, taskName: String, dueDate: Long) {
        viewModelScope.launch { repository.addTask(eventId, taskName, dueDate) }
    }

    fun updateTask(task: com.example.event_manager.data.TaskEntity) {
        viewModelScope.launch { repository.updateTask(task) }
    }

    fun addSchedule(eventId: Int, name: String, startTime: Long, endTime: Long) {
        viewModelScope.launch { repository.addSchedule(eventId, name, startTime, endTime) }
    }

    fun addExpense(eventId: Int, name: String, amount: Double) {
        viewModelScope.launch { repository.addExpense(eventId, name, amount) }
    }

    fun addFeedback(eventId: Int, guestId: Int, rating: Int, comment: String) {
        viewModelScope.launch { repository.addFeedback(eventId, guestId, rating, comment) }
    }

    fun invitationsFlow(eventId: Int) = repository.observeInvitations(eventId)
    fun messagesFlow(eventId: Int) = repository.observeMessages(eventId)
    fun budgetFlow(eventId: Int) = repository.observeBudget(eventId)
    fun schedulesFlow(eventId: Int) = repository.observeSchedules(eventId)
    fun tasksFlow(eventId: Int) = repository.observeTasks(eventId)
    fun feedbacksFlow(eventId: Int) = repository.observeFeedbacks(eventId)
    fun expensesFlow(eventId: Int) = repository.observeExpensesForEvent(eventId)
}

/**
 * Factory tạo EventViewModel thủ công vì repository cần EventDatabase từ Application.
 */
class EventViewModelFactory(
    db: EventDatabase,
    private val activity: Activity
) : ViewModelProvider.Factory {
    private val repository = EventRepository(db.eventDao())

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = EventViewModel(repository) as T
}
