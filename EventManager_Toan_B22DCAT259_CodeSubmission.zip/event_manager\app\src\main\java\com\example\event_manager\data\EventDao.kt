package com.example.event_manager.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/**
 * DAO trung tâm cho Room Database của module Event Manager.
 *
 * Quy ước:
 * - Các thao tác ghi dùng `suspend fun` để chạy trong coroutine.
 * - Các truy vấn hiển thị UI trả về `Flow<T>` để Compose tự cập nhật khi dữ liệu đổi.
 * - Các truy vấn JOIN trả về data class view như `EventSummary` và `InvitationWithGuest`.
 */
@Dao
interface EventDao {
    // Nhóm insert dùng REPLACE để đơn giản hóa prototype khi seed hoặc cập nhật dữ liệu.
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertUser(user: UserEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertEventType(type: EventTypeEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertLocation(location: LocationEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertEvent(event: EventEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertGuest(guest: GuestEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertInvitation(invitation: InvitationEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertNotification(notification: NotificationEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertBudget(budget: BudgetEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertExpense(expense: ExpenseEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertSchedule(schedule: ScheduleEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertSupplier(supplier: SupplierEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertEventSupplier(crossRef: EventSupplierEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertFeedback(feedback: FeedbackEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertTask(task: TaskEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertTaskAssignment(assignment: TaskAssignmentEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertMessageLog(messageLog: MessageLogEntity): Long

    // Nhóm update dùng khi thay đổi trạng thái sự kiện, RSVP, task hoặc check-in.
    @Update suspend fun updateEvent(event: EventEntity)
    @Update suspend fun updateInvitation(invitation: InvitationEntity)
    @Update suspend fun updateTask(task: TaskEntity)

    @Query("SELECT * FROM users LIMIT 1")
    suspend fun getCurrentUser(): UserEntity?

    @Query("SELECT * FROM event_types ORDER BY typeName")
    fun observeEventTypes(): Flow<List<EventTypeEntity>>

    @Query("SELECT * FROM guests ORDER BY guestName")
    fun observeGuests(): Flow<List<GuestEntity>>

    /**
     * Truy vấn danh sách sự kiện đã join với loại sự kiện và địa điểm.
     *
     * UI chỉ cần collect `EventSummary`, không phải tự truy vấn nhiều bảng.
     */
    @Query("""
        SELECT e.eventId, e.eventName, e.description, e.startDatetime, e.endDatetime, e.status,
               t.typeName AS typeName,
               l.locationName AS locationName, l.address AS address, l.googleMapsLink AS googleMapsLink,
               l.latitude AS latitude, l.longitude AS longitude
        FROM events e
        JOIN event_types t ON e.typeId = t.typeId
        JOIN locations l ON e.locationId = l.locationId
        ORDER BY e.startDatetime DESC
    """)
    fun observeEvents(): Flow<List<EventSummary>>

    /**
     * Truy vấn số liệu tổng quan dashboard.
     *
     * Kết quả gồm số sự kiện, số khách, RSVP và tỷ lệ sử dụng ngân sách.
     */
    @Query("""
        SELECT COUNT(*) AS totalEvents,
               COALESCE(SUM(CASE WHEN status = 'ACTIVE' THEN 1 ELSE 0 END), 0) AS activeEvents,
               (SELECT COUNT(*) FROM guests) AS totalGuests,
               (SELECT COUNT(*) FROM invitations WHERE responseStatus = 'ACCEPTED') AS acceptedGuests,
               (SELECT COUNT(*) FROM invitations WHERE responseStatus = 'PENDING') AS pendingGuests,
               (
                   COALESCE((SELECT SUM(expenses.amount)
                    FROM expenses
                    JOIN budgets ON expenses.budgetId = budgets.budgetId), 0.0)
                   /
                   CASE
                    WHEN COALESCE((SELECT SUM(estimatedBudget) FROM budgets),0.0) = 0 THEN 1
                    ELSE (SELECT SUM(estimatedBudget) FROM budgets)
                   END
               ) * 100 AS budgetUsage
        FROM events
    """)
    fun observeDashboard(): Flow<EventDashboard>

    @Query("SELECT * FROM events WHERE eventId = :eventId LIMIT 1")
    suspend fun getEvent(eventId: Int): EventEntity?

    @Query("SELECT * FROM locations WHERE locationId = :locationId LIMIT 1")
    suspend fun getLocation(locationId: Int): LocationEntity?

    @Query("SELECT * FROM budgets WHERE eventId = :eventId LIMIT 1")
    fun observeBudget(eventId: Int): Flow<BudgetEntity?>

    @Query("SELECT * FROM expenses WHERE budgetId = :budgetId ORDER BY expenseId DESC")
    fun observeExpenses(budgetId: Int): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM budgets WHERE budgetId = :budgetId LIMIT 1")
    suspend fun getBudgetById(budgetId: Int): BudgetEntity?

    @Query("SELECT * FROM schedules WHERE eventId = :eventId ORDER BY startTime")
    fun observeSchedules(eventId: Int): Flow<List<ScheduleEntity>>

    @Query("SELECT * FROM tasks WHERE eventId = :eventId ORDER BY dueDate")
    fun observeTasks(eventId: Int): Flow<List<TaskEntity>>

    @Query("SELECT * FROM feedbacks WHERE eventId = :eventId ORDER BY feedbackId DESC")
    fun observeFeedbacks(eventId: Int): Flow<List<FeedbackEntity>>

    /** Trả về danh sách lời mời kèm thông tin khách để màn hình guest/invitation hiển thị trực tiếp. */
    @Query("""
        SELECT i.invitationId, g.guestId, g.guestName, g.email, g.phone, i.sentAt, i.responseStatus, i.channel, i.invitationText, i.isCheckedIn
        FROM invitations i
        JOIN guests g ON i.guestId = g.guestId
        WHERE i.eventId = :eventId
        ORDER BY i.sentAt DESC
    """)
    fun observeInvitations(eventId: Int): Flow<List<InvitationWithGuest>>

    /** Cập nhật nhanh trạng thái check-in mà không phải load toàn bộ InvitationEntity lên UI. */
    @Query("UPDATE invitations SET isCheckedIn = :checkedIn WHERE invitationId = :invitationId")
    suspend fun updateCheckInStatus(invitationId: Int, checkedIn: Boolean)

    @Query("SELECT * FROM invitations WHERE invitationId = :invitationId LIMIT 1")
    suspend fun getInvitation(invitationId: Int): InvitationEntity?

    @Query("SELECT * FROM message_logs WHERE eventId = :eventId ORDER BY createdAt DESC")
    fun observeMessages(eventId: Int): Flow<List<MessageLogEntity>>

    @Query("SELECT * FROM notifications WHERE eventId = :eventId ORDER BY sentAt DESC")
    fun observeNotifications(eventId: Int): Flow<List<NotificationEntity>>

    @Query("DELETE FROM events")
    suspend fun clearEvents()

    @Query("SELECT COUNT(*) FROM events")
    suspend fun countEvents(): Int
}
