package com.example.event_manager.util

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys

/**
 * Trình Quản Lý Bảo Mật Lưu Trữ Dữ Liệu Nhạy Cảm (Security Management Helper).
 * Sử dụng thư viện bảo mật Android Jetpack Security (Crypto).
 * Hỗ trợ lưu trữ JWT Token và các dữ liệu tài khoản nhạy cảm dưới dạng mã hóa AES-256 an toàn
 * thông qua bộ khóa bảo mật Keystore phần cứng của Android.
 */
object SecurityHelper {

    // Tên tệp tin SharedPreferences được mã hóa lưu trong hệ thống
    private const val PREFS_NAME = "secure_event_manager_prefs"
    
    // Khóa định danh lưu trữ JWT Access Token
    private const val KEY_JWT_TOKEN = "jwt_access_token"
    
    // Khóa định danh lưu trữ Refresh Token
    private const val KEY_REFRESH_TOKEN = "jwt_refresh_token"
    
    // Khóa định danh lưu trữ Email người dùng đang đăng nhập
    private const val KEY_USER_EMAIL = "logged_user_email"

    /**
     * Khởi tạo hoặc truy xuất đối tượng EncryptedSharedPreferences bảo mật cao.
     * Tự động sinh khóa Master Key bằng thuật toán AES256_GCM để mã hóa cả Key và Value.
     * @param context Ngữ cảnh ứng dụng (Context).
     * @return SharedPreferences đã được mã hóa toàn diện bảo mật.
     */
    private fun getEncryptedPrefs(context: Context): android.content.SharedPreferences {
        // Sinh hoặc lấy khóa Master Key dùng cấu hình AES256_GCM từ hệ thống Keystore
        val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
        
        // Khởi tạo SharedPreferences mã hóa
        return EncryptedSharedPreferences.create(
            PREFS_NAME,
            masterKeyAlias,
            context,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV, // Mã hóa khóa (Key) bằng AES256-SIV
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM // Mã hóa giá trị (Value) bằng AES256-GCM
        )
    }

    /**
     * Lưu trữ an toàn JWT Access Token vào bộ nhớ mã hóa phần cứng.
     * @param context Ngữ cảnh ứng dụng.
     * @param token Chuỗi Access Token nhận được từ API login đám mây.
     */
    fun saveAccessToken(context: Context, token: String) {
        getEncryptedPrefs(context).edit().putString(KEY_JWT_TOKEN, token).apply()
    }

    /**
     * Truy xuất JWT Access Token đã lưu để đính kèm vào Header gọi API mạng.
     * @param context Ngữ cảnh ứng dụng.
     * @return Chuỗi token đã được tự động giải mã, hoặc null nếu chưa có.
     */
    fun getAccessToken(context: Context): String? {
        return getEncryptedPrefs(context).getString(KEY_JWT_TOKEN, null)
    }

    /**
     * Lưu trữ an toàn Refresh Token phục vụ gia hạn phiên làm việc ngầm.
     * @param context Ngữ cảnh ứng dụng.
     * @param token Chuỗi Refresh Token.
     */
    fun saveRefreshToken(context: Context, token: String) {
        getEncryptedPrefs(context).edit().putString(KEY_REFRESH_TOKEN, token).apply()
    }

    /**
     * Truy xuất Refresh Token đã lưu.
     * @param context Ngữ cảnh ứng dụng.
     * @return Chuỗi Refresh Token, hoặc null nếu chưa có.
     */
    fun getRefreshToken(context: Context): String? {
        return getEncryptedPrefs(context).getString(KEY_REFRESH_TOKEN, null)
    }

    /**
     * Lưu trữ Email của tài khoản người dùng hiện tại đang đăng nhập.
     * @param context Ngữ cảnh ứng dụng.
     * @param email Địa chỉ email tài khoản.
     */
    fun saveUserEmail(context: Context, email: String) {
        getEncryptedPrefs(context).edit().putString(KEY_USER_EMAIL, email).apply()
    }

    /**
     * Truy xuất Email của người dùng hiện tại phục vụ hiển thị Profile offline.
     * @param context Ngữ cảnh ứng dụng.
     * @return Địa chỉ email đã giải mã, hoặc null nếu chưa có.
     */
    fun getUserEmail(context: Context): String? {
        return getEncryptedPrefs(context).getString(KEY_USER_EMAIL, null)
    }

    /**
     * Xóa sạch toàn bộ thông tin phiên làm việc nhạy cảm (Đăng xuất - Logout).
     * Đảm bảo tính an toàn dữ liệu, không cho phép truy xuất trái phép sau khi người dùng thoát.
     * @param context Ngữ cảnh ứng dụng.
     */
    fun clearSession(context: Context) {
        getEncryptedPrefs(context).edit()
            .remove(KEY_JWT_TOKEN)
            .remove(KEY_REFRESH_TOKEN)
            .remove(KEY_USER_EMAIL)
            .apply()
    }
}
