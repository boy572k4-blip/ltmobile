package com.example.event_manager.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LightColors = lightColorScheme(
    primary = Color(0xFFF05778),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDCE4),
    onPrimaryContainer = Color(0xFF4B1120),
    secondary = Color(0xFF786CFF),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE3DFFF),
    onSecondaryContainer = Color(0xFF251C74),
    tertiary = Color(0xFFFFA37D),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFE0D3),
    background = Color(0xFFF8F6FB),
    onBackground = Color(0xFF1C1522),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1C1522),
    outlineVariant = Color(0xFFE9E1EC)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFFFB1C3),
    onPrimary = Color(0xFF650B25),
    primaryContainer = Color(0xFF89203C),
    onPrimaryContainer = Color(0xFFFFD9E2),
    secondary = Color(0xFFC5BEFF),
    onSecondary = Color(0xFF352C88),
    secondaryContainer = Color(0xFF4C42A0),
    onSecondaryContainer = Color(0xFFE4DFFF),
    tertiary = Color(0xFFFFB597),
    onTertiary = Color(0xFF5C1E00),
    tertiaryContainer = Color(0xFF7E3008),
    onTertiaryContainer = Color(0xFFFFDCCF),
    background = Color(0xFF141218),
    onBackground = Color(0xFFECE0ED),
    surface = Color(0xFF141218),
    onSurface = Color(0xFFECE0ED),
    outlineVariant = Color(0xFF4F4452)
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(14.dp),
    small = RoundedCornerShape(18.dp),
    medium = RoundedCornerShape(24.dp),
    large = RoundedCornerShape(30.dp),
    extraLarge = RoundedCornerShape(36.dp)
)

@Composable
fun EventManagerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = Typography,
        shapes = AppShapes,
        content = content
    )
}
