package com.example.event_manager.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.collect

/**
 * Repository nghiệp vụ của ứng dụng Event Manager.
 *
 * Lớp này là điểm trung gian giữa ViewModel và Room DAO. ViewModel không gọi
 * trực tiếp DAO để tránh trộn logic UI với logic dữ liệu. Những nghiệp vụ như
 * tạo sự kiện, gửi lời mời, check-in, gửi nhắc hẹn hoặc gửi khảo sát đều được
 * gom tại đây để dễ kiểm thử và mở rộng sang backend thật.
 */
class EventRepository(
    private val dao: EventDao
) {
    fun observeEvents(): Flow<List<EventSummary>> = dao.observeEvents()
    fun observeGuests(): Flow<List<GuestEntity>> = dao.observeGuests()
    fun observeDashboard(): Flow<EventDashboard> = dao.observeDashboard()
    fun observeEventTypes(): Flow<List<EventTypeEntity>> = dao.observeEventTypes()
    fun observeInvitations(eventId: Int): Flow<List<InvitationWithGuest>> = dao.observeInvitations(eventId)
    fun observeMessages(eventId: Int): Flow<List<MessageLogEntity>> = dao.observeMessages(eventId)
    fun observeBudget(eventId: Int): Flow<BudgetEntity?> = dao.observeBudget(eventId)
    fun observeSchedules(eventId: Int): Flow<List<ScheduleEntity>> = dao.observeSchedules(eventId)
    fun observeTasks(eventId: Int): Flow<List<TaskEntity>> = dao.observeTasks(eventId)
    fun observeFeedbacks(eventId: Int): Flow<List<FeedbackEntity>> = dao.observeFeedbacks(eventId)

    /**
     * Trả danh sách chi phí theo eventId.
     *
     * Vì `expenses` phụ thuộc `budgetId`, hàm này quan sát budget trước rồi mới
     * chuyển sang stream chi phí tương ứng. Nếu event chưa có budget thì trả
     * danh sách rỗng để UI không bị lỗi null.
     */
    fun observeExpensesForEvent(eventId: Int): Flow<List<ExpenseEntity>> =
        dao.observeBudget(eventId).map { budget -> budget?.budgetId }.let { budgetIds ->
            kotlinx.coroutines.flow.flow {
                budgetIds.collect { budgetId ->
                    if (budgetId == null) emit(emptyList())
                    else emitAll(dao.observeExpenses(budgetId))
                }
            }
        }

    /**
     * Tạo dữ liệu mẫu lần đầu chạy app.
     *
     * Hàm chỉ chạy khi bảng events đang rỗng, giúp demo có sẵn sự kiện, khách
     * mời, ngân sách, lịch trình và task mà không cần backend.
     */
    suspend fun ensureSeedData() {
        if (dao.countEvents() > 0) return

        val managerId = dao.insertUser(
            UserEntity(fullName = "Trần Hoàng Long", email = "long.tran@eventmanager.io", role = "Manager")
        ).toInt()

        val conferenceType = dao.insertEventType(EventTypeEntity(typeName = "Hội thảo")).toInt()
        val workshopType = dao.insertEventType(EventTypeEntity(typeName = "Workshop")).toInt()

        val hallLocation = dao.insertLocation(
            LocationEntity(
                locationName = "Trung tâm Hội nghị White Palace",
                address = "194 Hoàng Văn Thụ, Phường 9, Quận Phú Nhuận, TP. Hồ Chí Minh",
                capacity = 500,
                rentalCost = 45000000.0,
                latitude = 10.7997,
                longitude = 106.6749,
                googleMapsLink = "https://maps.google.com/?q=10.7997,106.6749"
            )
        ).toInt()

        val studioLocation = dao.insertLocation(
            LocationEntity(
                locationName = "Không gian Sáng tạo Creative Space",
                address = "1 Đại Cồ Việt, Bách Khoa, Hai Bà Trung, Hà Nội",
                capacity = 150,
                rentalCost = 12000000.0,
                latitude = 21.0057,
                longitude = 105.8434,
                googleMapsLink = "https://maps.google.com/?q=21.0057,105.8434"
            )
        ).toInt()

        val event1 = dao.insertEvent(
            EventEntity(
                eventName = "Hội Nghị Thượng Đỉnh Công Nghệ Việt Nam 2026",
                startDatetime = System.currentTimeMillis() + 86400000, // Ngày mai
                endDatetime = System.currentTimeMillis() + 86400000 + 28800000, // 8 tiếng
                description = "Sự kiện công nghệ thường niên quy tụ hàng trăm chuyên gia hàng đầu về AI, Cloud Computing và Blockchain tại Việt Nam.",
                status = EventStatus.ACTIVE,
                typeId = conferenceType,
                locationId = hallLocation,
                createdBy = managerId
            )
        ).toInt()

        val event2 = dao.insertEvent(
            EventEntity(
                eventName = "Workshop Thiết Kế Sản Phẩm UI/UX Chuyên Sâu",
                startDatetime = System.currentTimeMillis() + 86400000 * 5, // 5 ngày nữa
                endDatetime = System.currentTimeMillis() + 86400000 * 5 + 14400000, // 4 tiếng
                description = "Buổi thực hành kỹ năng thiết kế giao diện và trải nghiệm người dùng thực tế dành cho các Product Teams.",
                status = EventStatus.PLANNING,
                typeId = workshopType,
                locationId = studioLocation,
                createdBy = managerId
            )
        ).toInt()

        val budget1 = dao.insertBudget(BudgetEntity(eventId = event1, estimatedBudget = 150000000.0, warningLimit = 120000000.0)).toInt()
        dao.insertExpense(ExpenseEntity(budgetId = budget1, expenseName = "Đặt cọc sảnh tiệc White Palace", amount = 45000000.0))
        dao.insertExpense(ExpenseEntity(budgetId = budget1, expenseName = "Thiết kế & Lắp đặt Sân khấu, Đèn LED", amount = 35000000.0))
        dao.insertExpense(ExpenseEntity(budgetId = budget1, expenseName = "Chi phí Tiệc trà Break giữa giờ", amount = 20000000.0))
        dao.insertExpense(ExpenseEntity(budgetId = budget1, expenseName = "Quà tặng Lưu niệm VIP Box", amount = 15000000.0))

        dao.insertSchedule(ScheduleEntity(eventId = event1, activityName = "Đón khách và Check-in thẻ QR", startTime = System.currentTimeMillis() + 86400000, endTime = System.currentTimeMillis() + 86400000 + 3600000))
        dao.insertSchedule(ScheduleEntity(eventId = event1, activityName = "Khai mạc & Phát biểu của Ban tổ chức", startTime = System.currentTimeMillis() + 86400000 + 3600000, endTime = System.currentTimeMillis() + 86400000 + 5400000))
        dao.insertSchedule(ScheduleEntity(eventId = event1, activityName = "Phiên trình bày chính: Tương lai của AI tại Việt Nam", startTime = System.currentTimeMillis() + 86400000 + 5400000, endTime = System.currentTimeMillis() + 86400000 + 9000000))

        dao.insertTask(TaskEntity(eventId = event1, taskName = "Duyệt kịch bản MC và Slides trình bày", dueDate = System.currentTimeMillis() + 43200000, status = TaskStatus.DOING))
        dao.insertTask(TaskEntity(eventId = event1, taskName = "Kiểm tra hệ thống âm thanh, ánh sáng", dueDate = System.currentTimeMillis() + 64800000, status = TaskStatus.TODO))

        val alice = dao.insertGuest(GuestEntity(guestName = "Nguyễn Văn An", email = "an.nguyen@example.com", phone = "0901234567")).toInt()
        val bob = dao.insertGuest(GuestEntity(guestName = "Trần Thị Bình", email = "binh.tran@example.com", phone = "0912345678")).toInt()
        val celine = dao.insertGuest(GuestEntity(guestName = "Phạm Minh Cường", email = "cuong.pham@example.com", phone = "0923456789")).toInt()

        dao.insertInvitation(
            InvitationEntity(
                eventId = event1,
                guestId = alice,
                responseStatus = InvitationStatus.ACCEPTED,
                channel = InvitationChannel.GMAIL,
                invitationText = "Kính gửi anh Nguyễn Văn An, Ban tổ chức trân trọng kính mời anh tham dự Hội Nghị Thượng Đỉnh Công Nghệ Việt Nam 2026 vào ngày mai."
            )
        )
        dao.insertInvitation(
            InvitationEntity(
                eventId = event1,
                guestId = bob,
                responseStatus = InvitationStatus.PENDING,
                channel = InvitationChannel.ZALO,
                invitationText = "Chào chị Trần Thị Bình, đây là lời mời tham dự Hội Nghị Công Nghệ của chị."
            )
        )
        dao.insertInvitation(
            InvitationEntity(
                eventId = event2,
                guestId = celine,
                responseStatus = InvitationStatus.MAYBE,
                channel = InvitationChannel.FACEBOOK,
                invitationText = "Chào Cường, thư mời tham gia buổi thực hành thiết kế UI/UX sắp tới của bạn."
            )
        )

        dao.insertMessageLog(
            MessageLogEntity(
                eventId = event1,
                guestId = alice,
                channel = InvitationChannel.GMAIL,
                title = "Thư mời đã gửi thành công",
                body = "Thư mời điện tử đính kèm lịch trình chi tiết và liên kết định vị bản đồ White Palace.",
                statusText = "Đã Đồng Ý"
            )
        )
        dao.insertMessageLog(
            MessageLogEntity(
                eventId = event1,
                guestId = bob,
                channel = InvitationChannel.ZALO,
                title = "Đang chờ phản hồi lời mời",
                body = "Đã chia sẻ văn bản lời mời thành công qua kênh Zalo cá nhân.",
                statusText = "Chưa Phản Hồi"
            )
        )

        dao.insertFeedback(FeedbackEntity(eventId = event1, guestId = alice, rating = 5, comment = "Hội thảo tổ chức cực kỳ chuyên nghiệp, nội dung cập nhật AI rất hay và khâu check-in bằng mã QR rất mượt mà!"))
    }

    /**
     * Tạo sự kiện mới theo hướng offline-first.
     *
     * Dữ liệu được ghi vào Room trước. Khi SyncWorker chạy và có token hợp lệ,
     * dữ liệu local sẽ được đẩy lên REST API demo.
     */
    suspend fun createEvent(
        title: String,
        description: String,
        start: Long,
        end: Long,
        typeId: Int,
        locationName: String,
        address: String,
        mapsLink: String,
        lat: Double?,
        lng: Double?
    ) {
        val userId = dao.getCurrentUser()?.userId ?: dao.insertUser(
            UserEntity(fullName = "Default Manager", email = "admin@local.dev")
        ).toInt()

        val locationId = dao.insertLocation(
            LocationEntity(
                locationName = locationName,
                address = address,
                googleMapsLink = mapsLink,
                latitude = lat,
                longitude = lng
            )
        ).toInt()

        dao.insertEvent(
            EventEntity(
                eventName = title,
                description = description,
                startDatetime = start,
                endDatetime = end,
                typeId = typeId,
                locationId = locationId,
                createdBy = userId
            )
        )
    }

    /** Thêm khách mời mới vào danh bạ khách của hệ thống. */
    suspend fun createGuest(name: String, email: String, phone: String) {
        dao.insertGuest(GuestEntity(guestName = name, email = email, phone = phone))
    }

    /** Thêm task cần làm cho một sự kiện cụ thể. */
    suspend fun addTask(eventId: Int, taskName: String, dueDate: Long) {
        dao.insertTask(TaskEntity(eventId = eventId, taskName = taskName, dueDate = dueDate))
    }

    /** Cập nhật trạng thái/nội dung task đã có. */
    suspend fun updateTask(task: TaskEntity) {
        dao.updateTask(task)
    }

    /** Thêm một mốc lịch trình cho agenda của sự kiện. */
    suspend fun addSchedule(eventId: Int, activityName: String, startTime: Long, endTime: Long) {
        dao.insertSchedule(ScheduleEntity(eventId = eventId, activityName = activityName, startTime = startTime, endTime = endTime))
    }

    /**
     * Thêm chi phí cho sự kiện.
     *
     * Nếu sự kiện chưa có budget, repository tự tạo budget tạm để đảm bảo thao
     * tác nhập chi phí không bị gián đoạn trong bản demo.
     */
    suspend fun addExpense(eventId: Int, expenseName: String, amount: Double) {
        val existing = dao.observeBudget(eventId).first()
        val budgetId = existing?.budgetId ?: dao.insertBudget(
            BudgetEntity(eventId = eventId, estimatedBudget = amount * 4, warningLimit = amount * 3)
        ).toInt()
        dao.insertExpense(ExpenseEntity(budgetId = budgetId, expenseName = expenseName, amount = amount))
    }

    /** Ghi feedback đánh giá sau sự kiện của một khách mời. */
    suspend fun addFeedback(eventId: Int, guestId: Int, rating: Int, comment: String) {
        dao.insertFeedback(FeedbackEntity(eventId = eventId, guestId = guestId, rating = rating, comment = comment))
    }

    /**
     * Tạo lời mời và ghi message log.
     *
     * Phiên bản hiện tại chuẩn bị nội dung và log trong app. Việc gửi thực qua
     * Gmail/Zalo/Facebook được UI thực hiện bằng intent hoặc cần backend riêng.
     */
    suspend fun sendInvitation(
        eventId: Int,
        guestId: Int,
        channel: InvitationChannel,
        invitationText: String,
        mapsLink: String
    ) {
        dao.insertInvitation(
            InvitationEntity(
                eventId = eventId,
                guestId = guestId,
                channel = channel,
                invitationText = invitationText,
                mapsLink = mapsLink
            )
        )
        dao.insertMessageLog(
            MessageLogEntity(
                eventId = eventId,
                guestId = guestId,
                channel = channel,
                title = "Invitation prepared",
                body = invitationText,
                statusText = "Pending"
            )
        )
    }

    /** Cập nhật điểm danh khách mời và ghi lại lịch sử thao tác vào message log. */
    suspend fun updateCheckInStatus(invitationId: Int, checkedIn: Boolean) {
        dao.updateCheckInStatus(invitationId, checkedIn)
        val current = dao.getInvitation(invitationId) ?: return
        dao.insertMessageLog(
            MessageLogEntity(
                eventId = current.eventId,
                guestId = current.guestId,
                channel = current.channel,
                title = if (checkedIn) "Khách điểm danh tại sảnh" else "Hủy điểm danh khách",
                body = if (checkedIn) "Khách mời đã check-in thành công tại sảnh sự kiện." else "Hủy trạng thái check-in thành công.",
                statusText = if (checkedIn) "Đã Điểm Danh" else "Chưa Điểm Danh"
            )
        )
    }

    /** Ghi nhận thao tác gửi nhắc hẹn cho khách mời trước sự kiện. */
    suspend fun sendEventReminder(eventId: Int, invitationId: Int) {
        val current = dao.getInvitation(invitationId) ?: return
        dao.insertMessageLog(
            MessageLogEntity(
                eventId = eventId,
                guestId = current.guestId,
                channel = current.channel,
                title = "Đã gửi tin nhắc hẹn sự kiện",
                body = "Đã tự động gửi thông điệp nhắc nhở lịch trình và địa chỉ bản đồ sự kiện sắp bắt đầu.",
                statusText = "Đã Nhắc Nhở"
            )
        )
        dao.insertNotification(
            NotificationEntity(
                eventId = eventId,
                guestId = current.guestId,
                content = "Tin nhắn nhắc hẹn sự kiện đã được gửi.",
                channel = current.channel
            )
        )
    }

    /** Cập nhật phản hồi RSVP của khách mời và ghi log thay đổi. */
    suspend fun updateInvitationStatus(invitationId: Int, status: InvitationStatus) {
        val current = dao.getInvitation(invitationId) ?: return
        dao.updateInvitation(current.copy(responseStatus = status))
        dao.insertMessageLog(
            MessageLogEntity(
                eventId = current.eventId,
                guestId = current.guestId,
                channel = current.channel,
                title = "Cập nhật phản hồi từ khách",
                body = "Trạng thái lời mời của khách đã thay đổi thành $status.",
                statusText = status.name
            )
        )
    }

    /** Đánh dấu sự kiện đã hoàn thành. */
    suspend fun completeEvent(eventId: Int) {
        val event = dao.getEvent(eventId) ?: return
        dao.updateEvent(event.copy(status = EventStatus.COMPLETED))
    }

    /** Gửi khảo sát sau sự kiện cho các khách đã ACCEPTED. */
    suspend fun sendSurvey(eventId: Int) {
        val invitations = dao.observeInvitations(eventId).first().filter { it.responseStatus == InvitationStatus.ACCEPTED }
        invitations.forEach { invite ->
            dao.insertMessageLog(
                MessageLogEntity(
                    eventId = eventId,
                    guestId = invite.guestId,
                    channel = invite.channel,
                    title = "Survey sent",
                    body = "Thank you for attending. Please rate your event experience.",
                    statusText = "Survey"
                )
            )
            dao.insertNotification(
                NotificationEntity(
                    eventId = eventId,
                    guestId = invite.guestId,
                    content = "Survey request sent to ${invite.guestName}",
                    channel = invite.channel
                )
            )
        }
    }
}
