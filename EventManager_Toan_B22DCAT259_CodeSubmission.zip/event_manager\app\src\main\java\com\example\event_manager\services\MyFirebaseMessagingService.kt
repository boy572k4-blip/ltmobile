package com.example.event_manager.services

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.event_manager.MainActivity
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * Dịch Vụ Tiếp Nhận Thông Báo Đẩy Thời Gian Thực (Firebase Cloud Messaging Service).
 * Kế thừa lớp FirebaseMessagingService để lắng nghe, nhận dữ liệu thông báo được đẩy từ máy chủ đám mây,
 * hiển thị thông báo tức thời cho người dùng về tiến độ công việc, lời mời, phản hồi RSVP và sự kiện mới.
 */
class MyFirebaseMessagingService : FirebaseMessagingService() {

    /**
     * Hàm được gọi tự động khi thiết bị nhận được mã đăng ký Token FCM mới từ hệ thống Firebase.
     * Cần cập nhật token này lên Cloud Server để định danh thiết bị khi gửi push notification cá nhân.
     * @param token Chuỗi token đăng ký thiết bị mới nhận được.
     */
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d("FCM_Token", "FCM Device Registration Token mới được cấp: $token")
        // TODO: Gửi Token này lên Backend API của bạn thông qua EventApiService để lưu giữ phiên đẩy tin nhắn
    }

    /**
     * Phương thức được gọi tự động mỗi khi thiết bị nhận được thông điệp đẩy (RemoteMessage) từ Firebase Cloud.
     * Hỗ trợ tiếp nhận cả Data Payload (Dữ liệu ngầm) và Notification Payload (Nội dung hiển thị).
     * @param remoteMessage Đối tượng thông điệp chứa tiêu đề, nội dung và dữ liệu gửi đến.
     */
    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d("FCM_Message", "Nhận được bản tin đẩy FCM từ nguồn: ${remoteMessage.from}")

        // Trường hợp 1: Nhận bản tin dạng Data Payload (Dữ liệu ngầm tự phân tích)
        if (remoteMessage.data.isNotEmpty()) {
            val title = remoteMessage.data["title"] ?: "Thông báo sự kiện"
            val body = remoteMessage.data["body"] ?: "Bạn có một cập nhật hoạt động mới!"
            showNotification(title, body)
        }

        // Trường hợp 2: Nhận bản tin dạng Notification Payload (Nội dung hiển thị sẵn)
        remoteMessage.notification?.let {
            val title = it.title ?: "Thông báo từ Eventify"
            val body = it.body ?: "Có cập nhật lịch trình sự kiện mới!"
            showNotification(title, body)
        }
    }

    /**
     * Phương thức xử lý thiết lập kênh (Notification Channel) và hiển thị thông báo đẩy lên thanh trạng thái.
     * Hỗ trợ đầy đủ cơ chế bảo mật và yêu cầu kênh bắt buộc từ Android O (API 26) trở lên.
     * @param title Tiêu đề của thông báo hiển thị.
     * @param messageBody Nội dung văn bản chi tiết của thông báo.
     */
    private fun showNotification(title: String, messageBody: String) {
        // Thiết lập Intent mở màn hình chính MainActivity khi người dùng nhấn chọn thông báo
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP) // Đưa MainActivity lên đầu nếu đang chạy nền
        }
        
        // Khởi tạo PendingIntent bao bọc Intent an toàn
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE // FLAG_IMMUTABLE bắt buộc từ Android 12+
        )

        // Mã định danh độc nhất cho kênh thông báo đẩy của dự án
        val channelId = "event_management_notifications"
        
        // Xây dựng giao diện hiển thị thông báo
        val notificationBuilder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info) // Đặt biểu tượng mặc định hệ thống
            .setContentTitle(title) // Tiêu đề thông báo
            .setContentText(messageBody) // Nội dung thông báo
            .setAutoCancel(true) // Tự động xóa thông báo sau khi nhấn chọn
            .setContentIntent(pendingIntent) // Gắn Intent chuyển màn hình
            .setPriority(NotificationCompat.PRIORITY_DEFAULT) // Đặt mức độ ưu tiên mặc định hiển thị

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Tạo kênh thông báo bắt buộc cho các thiết bị chạy hệ điều hành Android O (API 26+) trở lên
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Event Management Notifications",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Kênh tiếp nhận các thông báo nhắc nhở lịch trình, công việc và RSVP từ ban tổ chức sự kiện"
            }
            notificationManager.createNotificationChannel(channel)
        }

        // Kích hoạt đẩy thông báo lên thanh trạng thái di động, định danh ngẫu nhiên bằng miliseconds để tránh đè lấp tin nhắn cũ
        notificationManager.notify(System.currentTimeMillis().toInt(), notificationBuilder.build())
    }
}
