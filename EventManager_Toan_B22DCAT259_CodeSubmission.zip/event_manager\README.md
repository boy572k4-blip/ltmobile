# Event Manager

Ứng dụng Android Studio viết bằng **Kotlin + Jetpack Compose + Room** cho bài toán quản lý sự kiện.

## Phần cá nhân thực hiện

Sinh viên **Trần Đình Toàn - B22DCAT259** phụ trách các module:

- Xác thực người dùng.
- Quản lý sự kiện.
- Quản lý khách mời.
- Thiết kế cơ sở dữ liệu Room/Firebase.
- Xây dựng biểu đồ UML và viết báo cáo kỹ thuật.

Chi tiết file liên quan nằm trong [`PERSONAL_CONTRIBUTION.md`](PERSONAL_CONTRIBUTION.md).

## Những gì đã có trong project

- Dashboard quản lý sự kiện
- Danh sách sự kiện + tạo/sửa nhanh
- Quản lý khách mời
- Trung tâm lời mời / message theo tab: Gmail, Facebook, Zalo, Manual
- Theo dõi phản hồi Accept / Pending / Decline
- Quản lý ngân sách, chi phí, lịch trình, công việc, nhà cung cấp
- Gửi khảo sát sau khi kết thúc sự kiện
- Hỗ trợ song ngữ Việt / Anh
- Tích hợp Google Maps mini map + search hook bằng Places API (cần API key)
- Chia sẻ nội dung lời mời bằng intent sang Gmail/Facebook/Zalo/ứng dụng khác
- Lưu dữ liệu cục bộ với Room

## Giới hạn kỹ thuật cần lưu ý

### 1) Gmail accept / decline trả ngược trực tiếp về app
Luồng này **không thể hoàn tất chỉ bằng app Android local**. Để email có nút Accept/Decline và đồng bộ ngược trạng thái thực sự, bạn cần thêm:
- backend/webhook
- dịch vụ gửi mail transactional
- deep link hoặc web app nhận phản hồi
- xác thực domain / OAuth nếu dùng Gmail API

Project này đã chuẩn bị:
- model dữ liệu cho invitations / message logs
- template nội dung mời
- nơi để gắn token deep link
- UI cập nhật trạng thái trong app

### 2) Facebook / Zalo API
Đúng như bạn nói, các nền tảng này bị giới hạn API và thường yêu cầu app review / business verification. Vì vậy trong project này:
- Facebook / Zalo dùng **share text thủ công qua intent**
- quản lý sự kiện có thể cập nhật trạng thái phản hồi trong app

## Cấu hình Google Maps / Places

Mở file `local.properties` và thêm:

```properties
MAPS_API_KEY=YOUR_GOOGLE_MAPS_KEY
```

Cần bật các API:
- Maps SDK for Android
- Places API
- Geocoding API (nếu muốn mở rộng)

## Chạy project

Mở bằng Android Studio, sync Gradle, chạy app.

## Gợi ý mở rộng tiếp theo

- đăng nhập nhiều tài khoản
- đồng bộ Firebase / Supabase
- backend nhận phản hồi email thật
- push notification
- upload ảnh sự kiện
- export PDF / Excel
