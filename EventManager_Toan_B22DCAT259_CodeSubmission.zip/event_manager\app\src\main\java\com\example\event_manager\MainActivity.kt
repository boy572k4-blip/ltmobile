package com.example.event_manager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.event_manager.ui.EventManagerAppScreen
import com.example.event_manager.ui.EventViewModel
import com.example.event_manager.ui.EventViewModelFactory
import com.example.event_manager.ui.theme.EventManagerTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as EventManagerApp
        setContent {
            EventManagerTheme(darkTheme = false) {
                val vm: EventViewModel = viewModel(factory = EventViewModelFactory(app.database, this))
                EventManagerAppScreen(vm = vm)
            }
        }
    }
}
