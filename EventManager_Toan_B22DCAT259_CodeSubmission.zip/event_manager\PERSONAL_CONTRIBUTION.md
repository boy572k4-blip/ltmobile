# Mô tả phần code cá nhân thực hiện

Sinh viên: Trần Đình Toàn - B22DCAT259  
Dự án: Event Manager Mobile App - Android Kotlin

## 1. Phạm vi module phụ trách

Các phần code liên quan trực tiếp đến nhiệm vụ cá nhân:

| Module | File liên quan | Vai trò |
|---|---|---|
| Xác thực người dùng | `data/remote/EventApiService.kt`, `util/SecurityHelper.kt`, `ui/EventManagerAppScreen.kt` | Khai báo API login/register, DTO token, giao diện đăng nhập/đăng ký, lưu Access Token/Refresh Token bằng EncryptedSharedPreferences. |
| Quản lý sự kiện | `data/Models.kt`, `data/EventDao.kt`, `data/EventRepository.kt`, `ui/EventViewModel.kt`, `ui/EventManagerAppScreen.kt` | Tạo sự kiện, danh sách sự kiện, chi tiết sự kiện, dashboard, lịch trình, ngân sách, chi phí, task, feedback. |
| Quản lý khách mời | `data/Models.kt`, `data/EventDao.kt`, `data/EventRepository.kt`, `ui/EventViewModel.kt`, `ui/EventManagerAppScreen.kt` | Quản lý guest, invitation, RSVP, check-in, message log, reminder, survey. |
| Thiết kế CSDL Room/Firebase | `data/Models.kt`, `data/EventDatabase.kt`, `data/EventDao.kt`, `services/MyFirebaseMessagingService.kt` | 16 entity Room, khóa ngoại, index, TypeConverter enum, service nhận FCM notification. |
| Đồng bộ và API ngoài | `data/remote/EventApiService.kt`, `services/SyncWorker.kt`, `EventManagerApp.kt` | Retrofit API, WorkManager chạy 2 giờ/lần, đọc Room và gọi cloud API demo. |
| UML và báo cáo | `BaoCaoKyThuat_TranDinhToan_B22DCAT259_BanChinhSua.docx` | Báo cáo kỹ thuật, sơ đồ kiến trúc MVVM, ERD Room, sequence đồng bộ. |

## 2. Trạng thái hoàn thiện code

Đã triển khai trong app:

- Room Database với 16 entity, khóa ngoại, index và TypeConverter cho enum.
- DAO dùng `Flow<T>` để UI cập nhật reactive.
- Repository gom logic nghiệp vụ: tạo sự kiện, thêm khách, gửi lời mời, cập nhật RSVP, check-in, thêm chi phí, thêm lịch trình, task, feedback, gửi reminder/survey.
- ViewModel dùng `StateFlow` và `viewModelScope.launch` để không block UI thread.
- Giao diện Compose cho các màn hình chính của ứng dụng.
- SecurityHelper dùng `EncryptedSharedPreferences` để lưu token an toàn.
- Retrofit interface cho login/register/events/RSVP.
- WorkManager `SyncWorker` cho đồng bộ nền Local → Cloud demo.
- Firebase Messaging Service nhận message và hiển thị notification.

Cần backend/Firebase thật để vận hành production:

- Nối UI login/register với `EventApiService.login()` và `EventApiService.register()`.
- Gửi FCM token trong `onNewToken()` lên backend.
- Hoàn thiện cloud → local trong `SyncWorker` bằng mapping `EventDto` về Room entity.
- Bổ sung `serverId`, `syncStatus`, `updatedAt` để xử lý trùng dữ liệu và conflict.
- Thêm `google-services.json` và plugin Google Services khi dùng Firebase project thật.

## 3. Hướng dẫn upload GitHub

Không upload các thư mục/file sinh tự động hoặc chứa cấu hình máy cá nhân:

- Không upload: `.gradle/`, `.idea/`, `build/`, `app/build/`, `local.properties`.
- Có thể upload: `local.properties.example` để người chấm biết cần cấu hình `MAPS_API_KEY` và `sdk.dir`.

Lệnh mẫu:

```bash
git init
git add .
git commit -m "Hoan thien module event manager ca nhan"
git branch -M main
git remote add origin https://github.com/<username>/<repo-name>.git
git push -u origin main
```

## 4. Cách build/chạy

1. Mở project bằng Android Studio.
2. Tạo `local.properties` từ `local.properties.example`.
3. Cấu hình đúng `sdk.dir` và `MAPS_API_KEY`.
4. Sync Gradle và chạy app trên thiết bị/AVD API 26+.

Ghi chú: file `local.properties` trong máy cá nhân không nên đưa lên GitHub vì chứa đường dẫn SDK/API key riêng.
