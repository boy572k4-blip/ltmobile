package com.example.event_manager.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.event_manager.data.EventSummary
import com.example.event_manager.data.GuestEntity
import com.example.event_manager.data.InvitationChannel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun formatDateTime(value: Long): String =
    SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(value))

fun formatMoney(value: Double): String = NumberFormat.getCurrencyInstance(Locale("vi", "VN")).format(value)

fun mapsLink(lat: Double?, lng: Double?, query: String = ""): String {
    return when {
        lat != null && lng != null -> "https://maps.google.com/?q=$lat,$lng"
        query.isNotBlank() -> "https://maps.google.com/?q=${Uri.encode(query)}"
        else -> ""
    }
}

fun buildInvitationText(event: EventSummary, guest: GuestEntity): String = """
Xin chào ${guest.guestName},

Bạn được mời tham dự sự kiện: ${event.eventName}
Thời gian: ${formatDateTime(event.startDatetime)} - ${formatDateTime(event.endDatetime)}
Địa điểm: ${event.locationName} - ${event.address}

Mô tả:
${event.description}

Chỉ đường Google Maps:
${event.googleMapsLink}

Vui lòng phản hồi trạng thái tham dự giúp ban tổ chức.
""".trimIndent()

fun shareInvitation(
    context: Context,
    channel: InvitationChannel,
    guest: GuestEntity,
    subject: String,
    body: String
) {
    when (channel) {
        InvitationChannel.GMAIL -> {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:${guest.email}")
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, body)
            }
            context.startActivity(Intent.createChooser(intent, "Send with Gmail"))
        }
        else -> {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, body)
            }
            context.startActivity(Intent.createChooser(intent, "Share invitation"))
        }
    }
}

fun copyToClipboard(context: Context, text: String) {
    val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    manager.setPrimaryClip(ClipData.newPlainText("invitation", text))
}
