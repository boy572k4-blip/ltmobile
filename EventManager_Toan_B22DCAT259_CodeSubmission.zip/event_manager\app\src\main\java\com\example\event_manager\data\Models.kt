package com.example.event_manager.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Tập enum dùng chung cho toàn bộ module quản lý sự kiện.
 *
 * Các enum này được lưu trong SQLite dưới dạng TEXT thông qua [EnumConverters]
 * tại file EventDatabase.kt. Cách này giúp dữ liệu trong Room dễ đọc và tránh
 * phụ thuộc vào ordinal của enum khi thứ tự enum thay đổi.
 */
enum class AppLanguage { VI, EN }
enum class EventStatus { PLANNING, ACTIVE, COMPLETED, CANCELLED }
enum class InvitationStatus { PENDING, ACCEPTED, DECLINED, MAYBE }
enum class InvitationChannel { GMAIL, FACEBOOK, ZALO, PHONE, MANUAL }
enum class TaskStatus { TODO, DOING, DONE, BLOCKED }

/**
 * Bảng người dùng/quản lý sự kiện.
 *
 * Trong bản prototype, user được dùng để liên kết người tạo sự kiện và người
 * được phân công task. Khi nối backend thật, userId local có thể cần ánh xạ
 * thêm với serverId để đồng bộ nhiều thiết bị.
 */
@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val userId: Int = 0,
    val fullName: String,
    val email: String,
    val password: String = "",
    val role: String = "Manager"
)

/** Danh mục loại sự kiện, ví dụ: hội thảo, workshop, tiệc, meeting. */
@Entity(tableName = "event_types")
data class EventTypeEntity(
    @PrimaryKey(autoGenerate = true) val typeId: Int = 0,
    val typeName: String
)

/**
 * Bảng địa điểm tổ chức sự kiện.
 *
 * Lưu cả địa chỉ dạng text và tọa độ để UI có thể hiển thị Google Maps/Places.
 */
@Entity(tableName = "locations")
data class LocationEntity(
    @PrimaryKey(autoGenerate = true) val locationId: Int = 0,
    val locationName: String,
    val address: String,
    val capacity: Int = 0,
    val rentalCost: Double = 0.0,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val googleMapsLink: String = ""
)

/**
 * Bảng sự kiện trung tâm của hệ thống.
 *
 * Mỗi event liên kết tới loại sự kiện, địa điểm và người tạo thông qua khóa
 * ngoại. Các bảng nghiệp vụ như invitations, budgets, schedules và tasks đều
 * tham chiếu ngược về eventId.
 */
@Entity(
    tableName = "events",
    foreignKeys = [
        ForeignKey(entity = EventTypeEntity::class, parentColumns = ["typeId"], childColumns = ["typeId"]),
        ForeignKey(entity = LocationEntity::class, parentColumns = ["locationId"], childColumns = ["locationId"]),
        ForeignKey(entity = UserEntity::class, parentColumns = ["userId"], childColumns = ["createdBy"])
    ],
    indices = [Index("typeId"), Index("locationId"), Index("createdBy")]
)
data class EventEntity(
    @PrimaryKey(autoGenerate = true) val eventId: Int = 0,
    val eventName: String,
    val startDatetime: Long,
    val endDatetime: Long,
    val description: String,
    val status: EventStatus = EventStatus.PLANNING,
    val typeId: Int,
    val locationId: Int,
    val createdBy: Int
)

/** Bảng khách mời độc lập, có thể được mời vào nhiều sự kiện khác nhau. */
@Entity(tableName = "guests")
data class GuestEntity(
    @PrimaryKey(autoGenerate = true) val guestId: Int = 0,
    val guestName: String,
    val email: String = "",
    val phone: String = ""
)

/**
 * Bảng lời mời, đóng vai trò bảng liên kết giữa sự kiện và khách mời.
 *
 * responseStatus lưu trạng thái RSVP; isCheckedIn lưu trạng thái điểm danh tại
 * sự kiện; channel ghi nhận kênh gửi lời mời như Gmail, Zalo hoặc thủ công.
 */
@Entity(
    tableName = "invitations",
    foreignKeys = [
        ForeignKey(entity = EventEntity::class, parentColumns = ["eventId"], childColumns = ["eventId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = GuestEntity::class, parentColumns = ["guestId"], childColumns = ["guestId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("eventId"), Index("guestId")]
)
data class InvitationEntity(
    @PrimaryKey(autoGenerate = true) val invitationId: Int = 0,
    val eventId: Int,
    val guestId: Int,
    val sentAt: Long = System.currentTimeMillis(),
    val responseStatus: InvitationStatus = InvitationStatus.PENDING,
    val channel: InvitationChannel = InvitationChannel.MANUAL,
    val invitationText: String = "",
    val mapsLink: String = "",
    val isCheckedIn: Boolean = false
)

/** Bảng thông báo nội bộ liên quan tới khách mời trong một sự kiện. */
@Entity(
    tableName = "notifications",
    foreignKeys = [
        ForeignKey(entity = EventEntity::class, parentColumns = ["eventId"], childColumns = ["eventId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = GuestEntity::class, parentColumns = ["guestId"], childColumns = ["guestId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("eventId"), Index("guestId")]
)
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val notificationId: Int = 0,
    val eventId: Int,
    val guestId: Int,
    val content: String,
    val sentAt: Long = System.currentTimeMillis(),
    val channel: InvitationChannel = InvitationChannel.MANUAL
)

/** Bảng ngân sách tổng của từng sự kiện, dùng để tính tỷ lệ sử dụng ngân sách. */
@Entity(
    tableName = "budgets",
    foreignKeys = [ForeignKey(entity = EventEntity::class, parentColumns = ["eventId"], childColumns = ["eventId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("eventId")]
)
data class BudgetEntity(
    @PrimaryKey(autoGenerate = true) val budgetId: Int = 0,
    val eventId: Int,
    val estimatedBudget: Double,
    val warningLimit: Double
)

/** Bảng chi phí chi tiết, phụ thuộc vào một bản ghi ngân sách. */
@Entity(
    tableName = "expenses",
    foreignKeys = [ForeignKey(entity = BudgetEntity::class, parentColumns = ["budgetId"], childColumns = ["budgetId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("budgetId")]
)
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true) val expenseId: Int = 0,
    val budgetId: Int,
    val expenseName: String,
    val amount: Double
)

/** Bảng lịch trình/agenda theo từng sự kiện, lưu thời gian ở dạng epoch millis. */
@Entity(
    tableName = "schedules",
    foreignKeys = [ForeignKey(entity = EventEntity::class, parentColumns = ["eventId"], childColumns = ["eventId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("eventId")]
)
data class ScheduleEntity(
    @PrimaryKey(autoGenerate = true) val scheduleId: Int = 0,
    val eventId: Int,
    val activityName: String,
    val startTime: Long,
    val endTime: Long
)

/** Bảng nhà cung cấp dịch vụ như âm thanh, ánh sáng, venue hoặc catering. */
@Entity(tableName = "suppliers")
data class SupplierEntity(
    @PrimaryKey(autoGenerate = true) val supplierId: Int = 0,
    val supplierName: String,
    val serviceType: String,
    val phone: String = "",
    val note: String = ""
)

/** Bảng trung gian nhiều-nhiều giữa sự kiện và nhà cung cấp. */
@Entity(
    tableName = "event_suppliers",
    foreignKeys = [
        ForeignKey(entity = EventEntity::class, parentColumns = ["eventId"], childColumns = ["eventId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = SupplierEntity::class, parentColumns = ["supplierId"], childColumns = ["supplierId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("eventId"), Index("supplierId")]
)
data class EventSupplierEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val eventId: Int,
    val supplierId: Int
)

/** Bảng feedback sau sự kiện, liên kết cả eventId và guestId. */
@Entity(
    tableName = "feedbacks",
    foreignKeys = [
        ForeignKey(entity = EventEntity::class, parentColumns = ["eventId"], childColumns = ["eventId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = GuestEntity::class, parentColumns = ["guestId"], childColumns = ["guestId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("eventId"), Index("guestId")]
)
data class FeedbackEntity(
    @PrimaryKey(autoGenerate = true) val feedbackId: Int = 0,
    val eventId: Int,
    val guestId: Int,
    val rating: Int,
    val comment: String
)

/** Bảng công việc cần làm trong từng sự kiện. */
@Entity(
    tableName = "tasks",
    foreignKeys = [ForeignKey(entity = EventEntity::class, parentColumns = ["eventId"], childColumns = ["eventId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("eventId")]
)
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val taskId: Int = 0,
    val eventId: Int,
    val taskName: String,
    val dueDate: Long,
    val status: TaskStatus = TaskStatus.TODO
)

/** Bảng phân công task cho user, thể hiện quan hệ nhiều-nhiều task-user. */
@Entity(
    tableName = "task_assignments",
    foreignKeys = [
        ForeignKey(entity = TaskEntity::class, parentColumns = ["taskId"], childColumns = ["taskId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = UserEntity::class, parentColumns = ["userId"], childColumns = ["userId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("taskId"), Index("userId")]
)
data class TaskAssignmentEntity(
    @PrimaryKey(autoGenerate = true) val assignmentId: Int = 0,
    val taskId: Int,
    val userId: Int
)

/**
 * Bảng nhật ký giao tiếp.
 *
 * Mọi thao tác gửi lời mời, nhắc hẹn, check-in hoặc khảo sát đều ghi log để UI
 * có lịch sử theo dõi theo từng sự kiện.
 */
@Entity(
    tableName = "message_logs",
    foreignKeys = [
        ForeignKey(entity = EventEntity::class, parentColumns = ["eventId"], childColumns = ["eventId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = GuestEntity::class, parentColumns = ["guestId"], childColumns = ["guestId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("eventId"), Index("guestId")]
)
data class MessageLogEntity(
    @PrimaryKey(autoGenerate = true) val messageId: Int = 0,
    val eventId: Int,
    val guestId: Int,
    val channel: InvitationChannel,
    val title: String,
    val body: String,
    val statusText: String,
    val createdAt: Long = System.currentTimeMillis()
)

data class EventSummary(
    val eventId: Int,
    val eventName: String,
    val description: String,
    val startDatetime: Long,
    val endDatetime: Long,
    val status: EventStatus,
    val typeName: String,
    val locationName: String,
    val address: String,
    val googleMapsLink: String,
    val latitude: Double? = null,
    val longitude: Double? = null
)

data class InvitationWithGuest(
    val invitationId: Int,
    val guestId: Int,
    val guestName: String,
    val email: String,
    val phone: String,
    val sentAt: Long,
    val responseStatus: InvitationStatus,
    val channel: InvitationChannel,
    val invitationText: String,
    val isCheckedIn: Boolean
)

data class ExpenseView(
    val expenseId: Int,
    val expenseName: String,
    val amount: Double
)

data class EventDashboard(
    val totalEvents: Int,
    val activeEvents: Int,
    val totalGuests: Int,
    val acceptedGuests: Int,
    val pendingGuests: Int,
    val budgetUsage: Double
)
