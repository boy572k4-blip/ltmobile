package com.example.event_manager.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters

class EnumConverters {
    @TypeConverter fun fromEventStatus(value: EventStatus): String = value.name
    @TypeConverter fun toEventStatus(value: String): EventStatus = EventStatus.valueOf(value)

    @TypeConverter fun fromInvitationStatus(value: InvitationStatus): String = value.name
    @TypeConverter fun toInvitationStatus(value: String): InvitationStatus = InvitationStatus.valueOf(value)

    @TypeConverter fun fromInvitationChannel(value: InvitationChannel): String = value.name
    @TypeConverter fun toInvitationChannel(value: String): InvitationChannel = InvitationChannel.valueOf(value)

    @TypeConverter fun fromTaskStatus(value: TaskStatus): String = value.name
    @TypeConverter fun toTaskStatus(value: String): TaskStatus = TaskStatus.valueOf(value)
}

@Database(
    entities = [
        UserEntity::class,
        EventTypeEntity::class,
        LocationEntity::class,
        EventEntity::class,
        GuestEntity::class,
        InvitationEntity::class,
        NotificationEntity::class,
        BudgetEntity::class,
        ExpenseEntity::class,
        ScheduleEntity::class,
        SupplierEntity::class,
        EventSupplierEntity::class,
        FeedbackEntity::class,
        TaskEntity::class,
        TaskAssignmentEntity::class,
        MessageLogEntity::class
    ],
    version = 2,
    exportSchema = false
)
@TypeConverters(EnumConverters::class)
abstract class EventDatabase : RoomDatabase() {
    abstract fun eventDao(): EventDao

    companion object {
        fun build(context: Context): EventDatabase =
            Room.databaseBuilder(context, EventDatabase::class.java, "event_manager.db")
                .fallbackToDestructiveMigration()
                .build()
    }
}
