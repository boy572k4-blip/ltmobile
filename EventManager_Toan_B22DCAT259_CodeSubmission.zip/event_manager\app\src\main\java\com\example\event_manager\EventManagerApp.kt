package com.example.event_manager

import android.app.Application
import com.example.event_manager.data.EventDatabase
import com.google.android.libraries.places.api.Places

class EventManagerApp : Application() {
    val database by lazy { EventDatabase.build(this) }

    override fun onCreate() {
        super.onCreate()
        if (!Places.isInitialized() && BuildConfig.MAPS_API_KEY.isNotBlank()) {
            Places.initialize(applicationContext, BuildConfig.MAPS_API_KEY)
        }
        
        // Kích hoạt tiến trình đồng bộ nền (Sync WorkManager)
        com.example.event_manager.services.SyncWorker.enqueuePeriodicSync(this)
    }
}
