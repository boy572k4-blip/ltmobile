package com.example.event_manager.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Checkbox
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.Event
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.event_manager.data.AppLanguage
import com.example.event_manager.data.EventSummary
import com.example.event_manager.data.GuestEntity
import com.example.event_manager.data.InvitationChannel
import com.example.event_manager.data.InvitationStatus
import com.example.event_manager.data.InvitationWithGuest
import com.example.event_manager.data.MessageLogEntity
import com.example.event_manager.util.formatDateTime
import com.example.event_manager.util.formatMoney
import androidx.compose.ui.platform.LocalContext
import android.content.Intent
import android.net.Uri
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng

private enum class AppStage { WELCOME, LOGIN, SIGNUP, FORGOT, APP }
private enum class MainTab { HOME, EVENTS, GUESTS, MESSAGES, PROFILE }

private data class Copy(
    val appName: String,
    val welcomeTop: String,
    val welcomeLine1: String,
    val welcomeLine2: String,
    val welcomeBody: String,
    val getStarted: String,
    val alreadyAccount: String,
    val logIn: String,
    val signUp: String,
    val createAccount: String,
    val joinCommunity: String,
    val fullName: String,
    val email: String,
    val password: String,
    val confirmPassword: String,
    val skip: String,
    val orContinue: String,
    val alreadyHaveAccount: String,
    val dontHaveAccount: String,
    val signUpFree: String,
    val welcomeBack: String,
    val loginHint: String,
    val forgot: String,
    val sendCode: String,
    val codeHint: String,
    val dashboard: String,
    val myInvitations: String,
    val selectEvent: String,
    val createEvent: String,
    val guestList: String,
    val messages: String,
    val profile: String,
    val vendors: String,
    val tasks: String,
    val budget: String,
    val addGuest: String,
    val inviteGuests: String,
    val noGuestsYet: String,
    val noTasksYet: String,
    val noVendorsYet: String,
    val responseAccepted: String,
    val responsePending: String,
    val responseDeclined: String,
    val invitationStatus: String,
    val languageToggle: String,
    val note: String,
    val importGuests: String,
    val addManual: String,
    val fromContacts: String,
    val logout: String
)

private fun copy(lang: AppLanguage) = Copy(
    appName = "EVENTO",
    welcomeTop = "Bắt đầu",
    welcomeLine1 = "Kiến tạo hành trình",
    welcomeLine2 = "trải nghiệm\nvô song",
    welcomeBody = "Ứng dụng chuyên nghiệp giúp lập kế hoạch, tổ chức và vận hành mọi sự kiện đỉnh cao trong tầm tay.",
    getStarted = "BẮT ĐẦU NGAY",
    alreadyAccount = "BẠN ĐÃ CÓ TÀI KHOẢN TỔ CHỨC?",
    logIn = "Đăng nhập",
    signUp = "Đăng ký tài khoản",
    createAccount = "Đăng ký\ntài khoản mới",
    joinCommunity = "Trở thành nhà tổ chức sự kiện chuyên nghiệp với các công cụ tối tân nhất.",
    fullName = "HỌ VÀ TÊN NHÀ TỔ CHỨC",
    email = "ĐỊA CHỈ GMAIL ĐĂNG KÝ",
    password = "MẬT KHẨU BẢO MẬT",
    confirmPassword = "XÁC NHẬN MẬT KHẨU",
    skip = "BỎ QUA",
    orContinue = "HOẶC TIẾP TỤC BẰNG",
    alreadyHaveAccount = "Đã đăng ký tài khoản?",
    dontHaveAccount = "Chưa có tài khoản?",
    signUpFree = "Đăng ký miễn phí",
    welcomeBack = "Chào mừng trở lại",
    loginHint = "Đăng nhập trợ lý số để vận hành sự kiện tiếp theo của bạn",
    forgot = "Quên mật khẩu?",
    sendCode = "Gửi mã xác minh",
    codeHint = "Vui lòng nhập địa chỉ Gmail để hệ thống gửi mã xác minh khôi phục mật khẩu bảo mật.",
    dashboard = "Trang chủ",
    myInvitations = "Lời mời vận hành",
    selectEvent = "Danh sách sự kiện",
    createEvent = "Tạo sự kiện mới",
    guestList = "Khách mời",
    messages = "Lịch sử hoạt động",
    profile = "Cá nhân",
    vendors = "Đối tác cung ứng",
    tasks = "Công việc chuẩn bị",
    budget = "Ngân sách",
    addGuest = "Thêm khách mời",
    inviteGuests = "Gửi lời mời",
    noGuestsYet = "Chưa có khách mời nào được thêm.",
    noTasksYet = "Chưa có đầu việc chuẩn bị nào.",
    noVendorsYet = "Chưa có đối tác liên kết.",
    responseAccepted = "Tham gia",
    responsePending = "Chờ phản hồi",
    responseDeclined = "Từ chối",
    invitationStatus = "Trạng thái thư mời",
    languageToggle = "Đổi ngôn ngữ (VI)",
    note = "Hệ thống quản lý thông minh hỗ trợ kết nối trực tuyến toàn diện cho nhà tổ chức.",
    importGuests = "Nhập danh sách excel",
    addManual = "Thêm thủ công",
    fromContacts = "Lấy từ danh bạ",
    logout = "Đăng xuất tài khoản"
)

@Composable
fun EventManagerAppScreen(vm: EventViewModel) {
    val lang = vm.language.value
    val copy = copy(lang)
    val events by vm.events.collectAsState()
    val guests by vm.guests.collectAsState()
    val dashboard by vm.dashboard.collectAsState()

    var stage by rememberSaveable { mutableStateOf(AppStage.WELCOME) }
    var tab by rememberSaveable { mutableStateOf(MainTab.HOME) }
    var email by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var signupName by rememberSaveable { mutableStateOf("") }
    var signupEmail by rememberSaveable { mutableStateOf("") }
    var signupPassword by rememberSaveable { mutableStateOf("") }
    var signupConfirm by rememberSaveable { mutableStateOf("") }
    var showAddGuest by rememberSaveable { mutableStateOf(false) }
    var showAddEvent by rememberSaveable { mutableStateOf(false) }
    var selectedEventId by rememberSaveable { mutableStateOf<Int?>(null) }

    Surface(color = Color(0xFFF7F3F5), modifier = Modifier.fillMaxSize()) {
        when (stage) {
            AppStage.WELCOME -> WelcomeScreen(
                copy = copy,
                onGetStarted = { stage = AppStage.SIGNUP },
                onLogin = { stage = AppStage.LOGIN }
            )
            AppStage.SIGNUP -> SignUpScreen(
                copy = copy,
                name = signupName,
                onName = { signupName = it },
                email = signupEmail,
                onEmail = { signupEmail = it },
                password = signupPassword,
                onPassword = { signupPassword = it },
                confirm = signupConfirm,
                onConfirm = { signupConfirm = it },
                onBack = { stage = AppStage.WELCOME },
                onSkip = { stage = AppStage.APP },
                onSignUp = { stage = AppStage.APP },
                onLogin = { stage = AppStage.LOGIN }
            )
            AppStage.LOGIN -> LoginScreen(
                copy = copy,
                email = email,
                onEmail = { email = it },
                password = password,
                onPassword = { password = it },
                onLogin = { stage = AppStage.APP },
                onForgot = { stage = AppStage.FORGOT },
                onSignUp = { stage = AppStage.SIGNUP }
            )
            AppStage.FORGOT -> ForgotScreen(
                copy = copy,
                email = email,
                onEmail = { email = it },
                onBack = { stage = AppStage.LOGIN },
                onContinue = { stage = AppStage.LOGIN }
            )
            AppStage.APP -> {
                val currentEvent = events.firstOrNull { it.eventId == (selectedEventId ?: vm.currentEvent(events)?.eventId) }
                    ?: vm.currentEvent(events)
                if (currentEvent != null) {
                    vm.selectEvent(currentEvent.eventId)
                }
                MainShell(
                    vm = vm,
                    copy = copy,
                    tab = tab,
                    onTab = { tab = it },
                    events = events,
                    guests = guests,
                    currentEvent = currentEvent,
                    dashboardLine = listOf(
                        dashboard.totalEvents.toString(),
                        dashboard.totalGuests.toString(),
                        dashboard.acceptedGuests.toString()
                    ),
                    onCreateEvent = { showAddEvent = true },
                    onAddGuest = { showAddGuest = true },
                    onSelectEvent = { selectedEventId = it; vm.selectEvent(it); tab = MainTab.EVENTS },
                    onToggleLanguage = { vm.toggleLanguage() },
                    onLogout = { stage = AppStage.LOGIN }
                )
                if (showAddGuest) {
                    AddGuestDialog(
                        copy = copy,
                        onDismiss = { showAddGuest = false },
                        onSave = { n, e, p ->
                            vm.addGuest(n, e, p)
                            showAddGuest = false
                        }
                    )
                }
                if (showAddEvent) {
                    AddEventDialog(
                        copy = copy,
                        onDismiss = { showAddEvent = false },
                        onSave = { title, desc, locName, addr, lat, lng ->
                            val start = System.currentTimeMillis() + 86400000L
                            val end = start + 28800000L
                            vm.createEvent(title, desc, start, end, typeId = 1, locName, addr, lat, lng)
                            showAddEvent = false
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun WelcomeScreen(copy: Copy, onGetStarted: () -> Unit, onLogin: () -> Unit) {
    val welcomeBgGradient = Brush.verticalGradient(
        listOf(Color(0xFF0F051D), Color(0xFF240A2F), Color(0xFF42072F))
    )
    PhoneFrame {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(welcomeBgGradient)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 24.dp, vertical = 26.dp)
            ) {
                Text(
                    text = "TRỢ LÝ TỔ CHỨC SỰ KIỆN SỐ",
                    color = Color(0xFFFF4B72),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.5.sp
                )
                Spacer(Modifier.height(12.dp))
                WelcomePoster(copy)
                Spacer(Modifier.height(30.dp))
                Button(
                    onClick = onGetStarted,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    contentPadding = PaddingValues()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(listOf(Color(0xFFE22D62), Color(0xFFFF5E8C))),
                                RoundedCornerShape(28.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(copy.getStarted, color = Color.White, fontWeight = FontWeight.ExtraBold)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.08f)),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            copy.alreadyAccount,
                            color = Color.White.copy(alpha = 0.6f),
                            style = MaterialTheme.typography.labelMedium
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            copy.logIn.uppercase(),
                            color = Color(0xFFFF4B72),
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.clickable(onClick = onLogin)
                        )
                    }
                }
                Spacer(Modifier.weight(1f))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.width(20.dp).height(5.dp).background(Color(0xFFE22D62), CircleShape))
                    Spacer(Modifier.width(6.dp))
                    Box(Modifier.width(6.dp).height(6.dp).background(Color.White.copy(alpha = 0.3f), CircleShape))
                    Spacer(Modifier.width(6.dp))
                    Box(Modifier.width(6.dp).height(6.dp).background(Color.White.copy(alpha = 0.3f), CircleShape))
                }
                Spacer(Modifier.height(10.dp))
            }
        }
    }
}

@Composable
private fun WelcomePoster(copy: Copy) {
    Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.06f)),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 24.dp)) {
            Text(
                copy.appName,
                color = Color.White,
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Black,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Text(
                "Ứng dụng quản lý sự kiện chuyên nghiệp",
                color = Color(0xFFFF4B72),
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(24.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF501248), Color(0xFF1E062B))))
            ) {
                Column(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(bottom = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("✨", fontSize = MaterialTheme.typography.headlineLarge.fontSize)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "KỊCH BẢN & PHÂN CÔNG TỰ ĐỘNG",
                        color = Color.White,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Black
                    )
                }
                Card(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.12f)),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier
                                .size(32.dp)
                                .background(Color(0xFFFF4B72), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("👑", style = MaterialTheme.typography.labelSmall)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(
                                "TỐI ƯU HIỆU SUẤT",
                                color = Color(0xFFFF5E8C),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "Vận hành kịch bản chính xác 100%.",
                                color = Color.White,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(22.dp))
            Text(
                copy.welcomeLine1,
                color = Color.White,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                copy.welcomeLine2,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Black,
                color = Color(0xFFFF4B72),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            Text(
                copy.welcomeBody,
                color = Color.White.copy(alpha = 0.7f),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun SignUpScreen(
    copy: Copy,
    name: String,
    onName: (String) -> Unit,
    email: String,
    onEmail: (String) -> Unit,
    password: String,
    onPassword: (String) -> Unit,
    confirm: String,
    onConfirm: (String) -> Unit,
    onBack: () -> Unit,
    onSkip: () -> Unit,
    onSignUp: () -> Unit,
    onLogin: () -> Unit
) {
    val welcomeBgGradient = Brush.verticalGradient(
        listOf(Color(0xFF0F051D), Color(0xFF240A2F), Color(0xFF42072F))
    )
    PhoneFrame {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(welcomeBgGradient)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                AuthTopBar(onBack = onBack, title = copy.appName, action = copy.skip, onAction = onSkip)
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 24.dp)
                ) {
                    Spacer(Modifier.height(10.dp))
                    Text(copy.createAccount, color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(8.dp))
                    Text(copy.joinCommunity, color = Color.White.copy(alpha = 0.7f))
                    Spacer(Modifier.height(20.dp))
                    
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.08f)),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            AuthField(copy.fullName, name, onName, Icons.Default.Person, "Họ và tên của bạn")
                            Spacer(Modifier.height(14.dp))
                            AuthField(copy.email, email, onEmail, Icons.Default.Email, "email@example.com")
                            Spacer(Modifier.height(14.dp))
                            PasswordField(copy.password, password, onPassword)
                            Spacer(Modifier.height(14.dp))
                            PasswordField(copy.confirmPassword, confirm, onConfirm)
                        }
                    }
                    
                    Spacer(Modifier.height(20.dp))
                    PrimaryPinkButton(text = copy.signUp, onClick = onSignUp)
                    Spacer(Modifier.height(18.dp))
                    CenterLineText(copy.orContinue)
                    Spacer(Modifier.height(18.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        SocialButton("Google", modifier = Modifier.weight(1f))
                        SocialButton("Facebook", modifier = Modifier.weight(1f), filled = true)
                    }
                    Spacer(Modifier.height(24.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                        Text(copy.alreadyHaveAccount, color = Color.White.copy(alpha = 0.7f))
                        Spacer(Modifier.width(6.dp))
                        Text(copy.logIn, color = Color(0xFFFF4B72), fontWeight = FontWeight.Black, modifier = Modifier.clickable(onClick = onLogin))
                    }
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
private fun LoginScreen(
    copy: Copy,
    email: String,
    onEmail: (String) -> Unit,
    password: String,
    onPassword: (String) -> Unit,
    onLogin: () -> Unit,
    onForgot: () -> Unit,
    onSignUp: () -> Unit
) {
    val welcomeBgGradient = Brush.verticalGradient(
        listOf(Color(0xFF0F051D), Color(0xFF240A2F), Color(0xFF42072F))
    )
    PhoneFrame {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(welcomeBgGradient)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(16.dp))
                Box(
                    Modifier
                        .size(54.dp)
                        .background(
                            Brush.verticalGradient(listOf(Color(0xFFFF4B72), Color(0xFFC12E57))),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text("🪄", fontSize = MaterialTheme.typography.titleLarge.fontSize)
                }
                Spacer(Modifier.height(18.dp))
                Text(copy.welcomeBack, color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(6.dp))
                Text(copy.loginHint, color = Color.White.copy(alpha = 0.7f), textAlign = TextAlign.Center)
                Spacer(Modifier.height(24.dp))
                
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.08f)),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f))
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        AuthField(copy.email, email, onEmail, Icons.Default.Email, "email@example.com")
                        Spacer(Modifier.height(16.dp))
                        PasswordField(copy.password, password, onPassword, trailingText = copy.forgot, onTrailingClick = onForgot)
                        Spacer(Modifier.height(24.dp))
                        PrimaryPinkButton(text = copy.logIn, onClick = onLogin)
                        Spacer(Modifier.height(18.dp))
                        CenterLineText(copy.orContinue)
                        Spacer(Modifier.height(18.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            SocialButton("Google", modifier = Modifier.weight(1f))
                            SocialButton("Facebook", modifier = Modifier.weight(1f))
                        }
                    }
                }
                Spacer(Modifier.height(24.dp))
                Row {
                    Text(copy.dontHaveAccount, color = Color.White.copy(alpha = 0.7f))
                    Spacer(Modifier.width(6.dp))
                    Text(copy.signUpFree, color = Color(0xFFFF4B72), fontWeight = FontWeight.Black, modifier = Modifier.clickable(onClick = onSignUp))
                }
            }
        }
    }
}

@Composable
private fun ForgotScreen(copy: Copy, email: String, onEmail: (String) -> Unit, onBack: () -> Unit, onContinue: () -> Unit) {
    val welcomeBgGradient = Brush.verticalGradient(
        listOf(Color(0xFF0F051D), Color(0xFF240A2F), Color(0xFF42072F))
    )
    PhoneFrame {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(welcomeBgGradient)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                AuthTopBar(onBack = onBack, title = copy.appName, action = copy.logIn, onAction = onBack)
                Column(modifier = Modifier.padding(24.dp)) {
                    Spacer(Modifier.height(20.dp))
                    Text(copy.sendCode, color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(10.dp))
                    Text(copy.codeHint, color = Color.White.copy(alpha = 0.7f))
                    Spacer(Modifier.height(24.dp))
                    AuthField(copy.email, email, onEmail, Icons.Default.Email, "email@gmail.com")
                    Spacer(Modifier.height(24.dp))
                    PrimaryPinkButton(text = copy.sendCode, onClick = onContinue)
                }
            }
        }
    }
}

@Composable
private fun MainShell(
    vm: EventViewModel,
    copy: Copy,
    tab: MainTab,
    onTab: (MainTab) -> Unit,
    events: List<EventSummary>,
    guests: List<GuestEntity>,
    currentEvent: EventSummary?,
    dashboardLine: List<String>,
    onCreateEvent: () -> Unit,
    onAddGuest: () -> Unit,
    onSelectEvent: (Int) -> Unit,
    onToggleLanguage: () -> Unit,
    onLogout: () -> Unit
) {
    Scaffold(
        containerColor = Color(0xFFF8F3F5),
        bottomBar = {
            NavigationBar(containerColor = Color(0xFFF8F3F5), tonalElevation = 0.dp, windowInsets = WindowInsets.navigationBars) {
                listOf(
                    Triple(MainTab.HOME, copy.dashboard, Icons.Outlined.Home),
                    Triple(MainTab.EVENTS, copy.selectEvent, Icons.Outlined.Event),
                    Triple(MainTab.GUESTS, copy.guestList, Icons.Outlined.Group),
                    Triple(MainTab.MESSAGES, copy.messages, Icons.Outlined.Notifications),
                    Triple(MainTab.PROFILE, copy.profile, Icons.Outlined.Person)
                ).forEach { (key, label, icon) ->
                    NavigationBarItem(
                        selected = tab == key,
                        onClick = { onTab(key) },
                        icon = { Icon(icon, null) },
                        label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        alwaysShowLabel = true
                    )
                }
            }
        },
        floatingActionButton = {
            if (tab == MainTab.GUESTS) {
                FloatingActionButton(onClick = onAddGuest, containerColor = Color(0xFFF15778)) {
                    Icon(Icons.Default.Add, null, tint = Color.White)
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                MainTab.HOME -> HomeScreen(copy, currentEvent, dashboardLine, onCreateEvent, onSelectEvent, events, onNavigateTab = onTab)
                MainTab.EVENTS -> EventsScreen(copy, events, currentEvent, vm, onSelectEvent, onCreateEvent = onCreateEvent, onNavigateTab = onTab)
                MainTab.GUESTS -> GuestsScreen(copy, guests, currentEvent, vm)
                MainTab.MESSAGES -> MessagesScreen(copy, vm, currentEvent)
                MainTab.PROFILE -> ProfileScreen(copy, onToggleLanguage, onLogout)
            }
        }
    }
}

@Composable
private fun HomeScreen(
    copy: Copy,
    currentEvent: EventSummary?,
    dashboardLine: List<String>,
    onCreateEvent: () -> Unit,
    onSelectEvent: (Int) -> Unit,
    events: List<EventSummary>,
    onNavigateTab: (MainTab) -> Unit
) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text(copy.appName, color = Color(0xFFE5335A), fontWeight = FontWeight.Bold)
                    Text("Chào mừng quay lại, Nhà tổ chức", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                }
                Box(Modifier.size(42.dp).background(Color.White, CircleShape), contentAlignment = Alignment.Center) {
                    Text("👩🏻", style = MaterialTheme.typography.titleLarge)
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(30.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFFDECEF))) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text("Bảng Điều Phối Sự Kiện", color = Color(0xFF7D767A), style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        TinyMetric("Sự kiện", dashboardLine.getOrElse(0) { "0" }, Modifier.weight(1f))
                        TinyMetric("Khách mời", dashboardLine.getOrElse(1) { "0" }, Modifier.weight(1f))
                        TinyMetric("Tham gia", dashboardLine.getOrElse(2) { "0" }, Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(16.dp))
                    PrimaryPinkButton(text = copy.createEvent, onClick = onCreateEvent)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                QuickMenuCard("Sự kiện", dashboardLine.getOrElse(0) { "0" }, Icons.Default.Event, Modifier.weight(1f), onClick = { onNavigateTab(MainTab.EVENTS) })
                QuickMenuCard("Khách mời", dashboardLine.getOrElse(1) { "0" }, Icons.Default.Group, Modifier.weight(1f), onClick = { onNavigateTab(MainTab.GUESTS) })
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                QuickMenuCard("Ngân sách", "Chi tiết", Icons.Default.CheckCircle, Modifier.weight(1f), onClick = { onNavigateTab(MainTab.EVENTS) })
                QuickMenuCard("Công việc", "Xem lịch", Icons.Default.CalendarMonth, Modifier.weight(1f), onClick = { onNavigateTab(MainTab.EVENTS) })
            }
        }
        item {
            Text("Địa điểm nổi bật", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        items(events.take(2)) { event ->
            FeaturedEventCard(event, onClick = { onSelectEvent(event.eventId); onNavigateTab(MainTab.EVENTS) })
        }
        item {
            Text(copy.myInvitations, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        if (currentEvent != null) {
            item { EventDigestCard(currentEvent, onOpen = { onSelectEvent(currentEvent.eventId); onNavigateTab(MainTab.EVENTS) }) }
        }
        item {
            Card(shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Text(copy.note, modifier = Modifier.padding(16.dp), color = Color(0xFF7A7478))
            }
        }
    }
}

@Composable
private fun EventsScreen(
    copy: Copy,
    events: List<EventSummary>,
    currentEvent: EventSummary?,
    vm: EventViewModel,
    onSelectEvent: (Int) -> Unit,
    onCreateEvent: () -> Unit,
    onNavigateTab: (MainTab) -> Unit
) {
    val event = currentEvent ?: events.firstOrNull()
    var searchQuery by remember { mutableStateOf("") }
    val filteredEvents = remember(events, searchQuery) {
        if (searchQuery.isBlank()) events
        else events.filter { it.eventName.contains(searchQuery, ignoreCase = true) || it.description.contains(searchQuery, ignoreCase = true) }
    }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text(copy.selectEvent, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
            }
        }
        item {
            androidx.compose.material3.OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                placeholder = { Text("Tìm kiếm sự kiện của bạn...") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                trailingIcon = { 
                    IconButton(onClick = onCreateEvent) {
                        Icon(Icons.Default.Add, null, tint = Color(0xFFC43058))
                    }
                },
                singleLine = true
            )
        }
        items(filteredEvents) { ev ->
            EventSelectorCard(event = ev, selected = event?.eventId == ev.eventId, onClick = { onSelectEvent(ev.eventId) })
        }
        if (event != null) {
            item { LargeEventDetailCard(event) }
            item { EventActionsCard(vm, event, onNavigateTab = onNavigateTab) }
            item { BudgetPreviewCard(copy, vm, event.eventId) }
            item { TaskPreviewCard(copy, vm, event.eventId) }
            item { TimelinePreviewCard(copy, vm, event) }
            item { InvitationPreviewCard(copy, vm, event.eventId) }
            item { FeedbackPreviewCard(copy, vm, event.eventId) }
        }
    }
}

@Composable
private fun GuestDetailDialog(
    guest: GuestEntity,
    invite: InvitationWithGuest?,
    currentEvent: EventSummary?,
    vm: EventViewModel,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Hồ sơ khách mời",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFFC43058)
            )
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Đóng", color = Color(0xFFC43058), fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEEF2)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text(guest.guestName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFFB9305A))
                        Spacer(Modifier.height(4.dp))
                        Text("📧 Gmail: ${guest.email.ifBlank { "Chưa cập nhật" }}", style = MaterialTheme.typography.bodyMedium)
                        Text("📞 Điện thoại: ${guest.phone.ifBlank { "Chưa cập nhật" }}", style = MaterialTheme.typography.bodyMedium)
                    }
                }

                if (currentEvent != null) {
                    Text("Thông tin sự kiện: ${currentEvent.eventName}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    if (invite != null) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, Color(0xFFFFEEF2)),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Trạng thái phản hồi:", style = MaterialTheme.typography.bodyMedium)
                                    Text(
                                        text = when(invite.responseStatus) {
                                            InvitationStatus.ACCEPTED -> "Tham gia"
                                            InvitationStatus.DECLINED -> "Từ chối"
                                            InvitationStatus.MAYBE -> "Có thể"
                                            InvitationStatus.PENDING -> "Chờ phản hồi"
                                        },
                                        fontWeight = FontWeight.Bold,
                                        color = when(invite.responseStatus) {
                                            InvitationStatus.ACCEPTED -> Color(0xFF39A86B)
                                            InvitationStatus.DECLINED -> Color(0xFFE35B63)
                                            else -> Color(0xFFFFC107)
                                        }
                                    )
                                }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Kênh liên hệ:", style = MaterialTheme.typography.bodyMedium)
                                    Text(invite.channel.name, fontWeight = FontWeight.Bold)
                                }
                                
                                Divider(color = Color(0xFFFFEEF2))

                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Điểm danh tại cổng sảnh", fontWeight = FontWeight.Bold)
                                        Text(
                                            text = if (invite.isCheckedIn) "🟢 Đã điểm danh" else "⚫ Chưa điểm danh",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (invite.isCheckedIn) Color(0xFF39A86B) else Color.Gray
                                        )
                                    }
                                    androidx.compose.material3.Switch(
                                        checked = invite.isCheckedIn,
                                        onCheckedChange = { checked ->
                                            vm.updateCheckIn(invite.invitationId, checked)
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = {
                                vm.sendEventReminder(currentEvent.eventId, invite.invitationId)
                            },
                            modifier = Modifier.fillMaxWidth().height(44.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB9305A)),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.Notifications, null, modifier = Modifier.size(16.dp), tint = Color.White)
                                Spacer(Modifier.width(8.dp))
                                Text("Nhắc hẹn sự kiện sắp diễn ra", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    } else {
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = {
                                vm.sendInvitation(currentEvent, guest, InvitationChannel.GMAIL)
                            },
                            modifier = Modifier.fillMaxWidth().height(44.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF39A86B)),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Email, null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("Gửi lời mời tham gia sự kiện", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    )
}

@Composable
private fun GuestsScreen(
    copy: Copy,
    guests: List<GuestEntity>,
    currentEvent: EventSummary?,
    vm: EventViewModel
) {
    var searchQuery by remember { mutableStateOf("") }
    var filterState by remember { mutableStateOf("All") } // "All", "Confirmed", "VIP"
    var selectedGuestForDetail by remember { mutableStateOf<GuestEntity?>(null) }

    val invitations by if (currentEvent != null) {
        vm.invitationsFlow(currentEvent.eventId).collectAsState(initial = emptyList())
    } else {
        remember { mutableStateOf(emptyList()) }
    }

    val filteredGuests = remember(guests, searchQuery, filterState, invitations) {
        guests.filter { guest ->
            val matchesSearch = guest.guestName.contains(searchQuery, ignoreCase = true) || guest.email.contains(searchQuery, ignoreCase = true)
            val matchesFilter = when (filterState) {
                "Confirmed" -> invitations.any { it.guestId == guest.guestId && it.responseStatus == InvitationStatus.ACCEPTED }
                "VIP" -> guest.email.contains("vip", ignoreCase = true) || guest.guestName.contains("vip", ignoreCase = true)
                else -> true
            }
            matchesSearch && matchesFilter
        }
    }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text(copy.guestList, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                Icon(Icons.Default.Search, null, tint = Color(0xFFC43058))
            }
        }
        item {
            androidx.compose.material3.OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                placeholder = { Text("Tìm kiếm khách mời...") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterPill("Tất cả", selected = filterState == "All") { filterState = "All" }
                FilterPill("Đã xác nhận", selected = filterState == "Confirmed") { filterState = "Confirmed" }
                FilterPill("Khách VIP", selected = filterState == "VIP") { filterState = "VIP" }
            }
        }
        item {
            Card(shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFB9305A))) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    val countCheck = invitations.count { it.isCheckedIn }
                    Text("Đã điểm danh $countCheck khách sảnh", color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("Nhấn vào khách để chỉnh sửa hồ sơ, điểm danh cổng hoặc gửi nhắc nhở sự kiện.", color = Color.White.copy(alpha = 0.85f))
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                SoftActionChip(copy.addManual)
                SoftActionChip(copy.fromContacts)
                SoftActionChip(copy.importGuests)
            }
        }
        if (filteredGuests.isEmpty()) {
            item { EmptyPanel(title = copy.noGuestsYet, cta = copy.addGuest) }
        } else {
            items(filteredGuests) { guest ->
                val invite = invitations.firstOrNull { it.guestId == guest.guestId }
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedGuestForDetail = guest }
                ) {
                    Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).background(Color(0xFFFFE4EA), CircleShape), contentAlignment = Alignment.Center) {
                            Text(guest.guestName.take(1), color = Color(0xFFC43058), fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(guest.guestName, fontWeight = FontWeight.SemiBold)
                            Text(guest.phone.ifBlank { guest.email }, color = Color(0xFF8A8488))
                            if (invite != null && invite.isCheckedIn) {
                                Spacer(Modifier.height(2.dp))
                                Text("🟢 Đã điểm danh cổng", color = Color(0xFF39A86B), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            }
                        }
                        FilterPill(if (guest.email.contains("vip", true)) "VIP" else "Khách mời", selected = guest.email.contains("vip", true)) {}
                    }
                }
            }
        }
    }

    if (selectedGuestForDetail != null) {
        val guest = selectedGuestForDetail!!
        val invite = invitations.firstOrNull { it.guestId == guest.guestId }
        GuestDetailDialog(
            guest = guest,
            invite = invite,
            currentEvent = currentEvent,
            vm = vm,
            onDismiss = { selectedGuestForDetail = null }
        )
    }
}

@Composable
private fun MessagesScreen(copy: Copy, vm: EventViewModel, currentEvent: EventSummary?) {
    if (currentEvent == null) {
        EmptyPanel(title = copy.messages, cta = copy.selectEvent)
        return
    }
    val invitations by vm.invitationsFlow(currentEvent.eventId).collectAsState(initial = emptyList())
    val messages by vm.messagesFlow(currentEvent.eventId).collectAsState(initial = emptyList())
    var filter by rememberSaveable { mutableStateOf(InvitationChannel.GMAIL) }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text(copy.messages, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
            Text(currentEvent.eventName, color = Color(0xFF8A8387))
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterPill("Bộ lọc", selected = false) {}
                listOf(InvitationChannel.GMAIL, InvitationChannel.ZALO, InvitationChannel.FACEBOOK).forEach { channel ->
                    FilterPill(channel.name, selected = filter == channel) { filter = channel }
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFF25A7D))) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("Trung Tâm Hoạt Động & Tin Nhắn", color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = {}, shape = RoundedCornerShape(20.dp), border = BorderStroke(0.dp, Color.Transparent), colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.White.copy(alpha = 0.22f), contentColor = Color.White)) {
                        Text("Xem nội dung lịch sử kênh ${filter.name}")
                    }
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    StatusDot(copy.responseAccepted, invitations.count { it.responseStatus == InvitationStatus.ACCEPTED })
                    StatusDot(copy.responsePending, invitations.count { it.responseStatus == InvitationStatus.PENDING })
                    StatusDot(copy.responseDeclined, invitations.count { it.responseStatus == InvitationStatus.DECLINED })
                }
            }
        }
        items(invitations.filter { it.channel == filter }.ifEmpty { invitations }) { invite ->
            InvitationStatusRow(invite, vm)
        }
        if (messages.isNotEmpty()) {
            item { Text("Hoạt động gần đây", fontWeight = FontWeight.Bold) }
            items(messages.take(4)) { message -> MessageRow(message) }
        }
    }
}

@Composable
private fun ProfileScreen(copy: Copy, onToggleLanguage: () -> Unit, onLogout: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text(copy.profile, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
        }
        item {
            Card(shape = RoundedCornerShape(30.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(78.dp).background(Color(0xFFFFE6EC), CircleShape), contentAlignment = Alignment.Center) {
                        Text("👩🏻", style = MaterialTheme.typography.headlineMedium)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("Trần Hoàng Long", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("long.tran@eventmanager.io", color = Color(0xFF847D82))
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SoftActionChip("Ngôn ngữ")
                        SoftActionChip("Bảo mật")
                    }
                }
            }
        }
        item { ProfileAction(icon = Icons.Default.Language, title = copy.languageToggle, onClick = onToggleLanguage) }
        item { ProfileAction(icon = Icons.Default.Email, title = "Xác thực Gmail / Firebase", subtitle = copy.note, onClick = {}) }
        item { ProfileAction(icon = Icons.Default.Person, title = "Cấu hình mật khẩu", subtitle = "Thay đổi, cập nhật thông tin và mã bảo mật khóa tài khoản.", onClick = {}) }
        item { ProfileAction(icon = Icons.Default.Person, title = copy.logout, onClick = onLogout) }
    }
}

@Composable
private fun QuickMenuCard(title: String, value: String, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    Card(modifier = modifier.clickable(onClick = onClick), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(16.dp)) {
            Box(Modifier.size(36.dp).background(Color(0xFFFFEEF3), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = Color(0xFFC43058))
            }
            Spacer(Modifier.height(14.dp))
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            Text(title, color = Color(0xFF847E82))
        }
    }
}

@Composable
private fun EventDigestCard(event: EventSummary, onOpen: () -> Unit) {
    Card(shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.clickable(onClick = onOpen)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text(event.eventName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(formatDateTime(event.startDatetime), color = Color(0xFF7A7377))
            Spacer(Modifier.height(8.dp))
            Text(event.description, maxLines = 2, overflow = TextOverflow.Ellipsis, color = Color(0xFF7A7377))
        }
    }
}

@Composable
private fun EventSelectorCard(event: EventSummary, selected: Boolean, onClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFFFFF0F4) else Color.White),
        border = if (selected) BorderStroke(1.dp, Color(0xFFF26788)) else null,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).background(Color(0xFFFFE7ED), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Event, null, tint = Color(0xFFC43058))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(event.eventName, fontWeight = FontWeight.Bold)
                Text(event.locationName, color = Color(0xFF847E82))
            }
            Text(if (selected) "Open" else "View", color = Color(0xFFC43058), fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun EventActionsCard(vm: EventViewModel, event: EventSummary, onNavigateTab: (MainTab) -> Unit) {
    val context = LocalContext.current
    Card(shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Thao Tác Nhanh", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                SoftActionChip("Gửi thư mời", onClick = {
                    vm.sendSurvey(event.eventId)
                    android.widget.Toast.makeText(context, "Đã gửi thư mời/khảo sát hàng loạt cho khách mời!", android.widget.Toast.LENGTH_SHORT).show()
                })
                SoftActionChip("Phản hồi khách", onClick = {
                    onNavigateTab(MainTab.MESSAGES)
                })
                SoftActionChip("Bản đồ", onClick = {
                    val intentUri = Uri.parse("geo:${event.latitude ?: 10.7731},${event.longitude ?: 106.7042}?q=${Uri.encode(event.locationName + ", " + event.address)}")
                    val intent = Intent(Intent.ACTION_VIEW, intentUri).apply {
                        setPackage("com.google.android.apps.maps")
                    }
                    try {
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(event.googleMapsLink.ifBlank { "https://maps.google.com/?q=${event.latitude},${event.longitude}" })))
                    }
                })
            }
        }
    }
}

@Composable
private fun GuestStatusCard(guest: GuestEntity) {
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Color(0xFFFFE4EA), CircleShape), contentAlignment = Alignment.Center) {
                Text(guest.guestName.take(1), color = Color(0xFFC43058), fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(guest.guestName, fontWeight = FontWeight.SemiBold)
                Text(guest.phone.ifBlank { guest.email }, color = Color(0xFF8A8488))
            }
            FilterPill(if (guest.email.contains("vip", true)) "VIP" else "Guest", selected = guest.email.contains("vip", true)) {}
        }
    }
}

@Composable
private fun FeaturedEventCard(event: EventSummary, onClick: () -> Unit = {}) {
    Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.clickable(onClick = onClick)) {
        Column(Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(172.dp)
                    .background(Brush.verticalGradient(listOf(Color(0xFFB68452), Color(0xFF3B2F30))))
            ) {
                Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
                    Text(event.eventName, color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                    Text(formatDateTime(event.startDatetime), color = Color.White.copy(alpha = 0.85f))
                }
            }
            Column(Modifier.padding(16.dp)) {
                Text(event.description, maxLines = 2, overflow = TextOverflow.Ellipsis, color = Color(0xFF6F6A6D))
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, null, tint = Color(0xFFF15778), modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(event.locationName, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun LargeEventDetailCard(event: EventSummary) {
    val context = LocalContext.current
    val eventLocation = LatLng(event.latitude ?: 10.7731, event.longitude ?: 106.7042)
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(eventLocation, 15f)
    }

    Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier.fillMaxWidth().height(170.dp)
                    .background(Brush.verticalGradient(listOf(Color(0xFFF5D7DF), Color(0xFFF3F0F2))))
            ) {
                Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
                    Text(event.eventName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                    Text(event.typeName, color = Color(0xFFC43058), fontWeight = FontWeight.Bold)
                }
            }
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                DetailLine(Icons.Default.CalendarMonth, formatDateTime(event.startDatetime))
                DetailLine(Icons.Default.LocationOn, event.address)
                DetailLine(Icons.Default.ContentCopy, event.googleMapsLink.ifBlank { "Không có liên kết bản đồ" })
                
                // Đếm ngược thời gian thực sự kiện bắt đầu hoặc trạng thái đang diễn ra
                val currentTime = System.currentTimeMillis()
                val timeDiff = event.startDatetime - currentTime
                if (timeDiff > 0) {
                    val days = timeDiff / (24 * 3600 * 1000)
                    val hours = (timeDiff % (24 * 3600 * 1000)) / (3600 * 1000)
                    val minutes = (timeDiff % (3600 * 1000)) / (60 * 1000)
                    Spacer(Modifier.height(4.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF0F3)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("⏰", fontSize = MaterialTheme.typography.titleLarge.fontSize)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("Đếm ngược thời gian bắt đầu:", style = MaterialTheme.typography.labelSmall, color = Color.Gray, fontWeight = FontWeight.Bold)
                                Text(
                                    text = "Còn lại $days ngày $hours giờ $minutes phút",
                                    color = Color(0xFFC43058),
                                    fontWeight = FontWeight.ExtraBold,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }
                } else {
                    val isOngoing = currentTime in event.startDatetime..event.endDatetime
                    Spacer(Modifier.height(4.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = if (isOngoing) Color(0xFFE8F5E9) else Color(0xFFECEFF1)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (isOngoing) "🟢" else "⚫", fontSize = MaterialTheme.typography.titleLarge.fontSize)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("Trạng thái sự kiện:", style = MaterialTheme.typography.labelSmall, color = Color.Gray, fontWeight = FontWeight.Bold)
                                Text(
                                    text = if (isOngoing) "Đang diễn ra" else "Đã kết thúc",
                                    color = if (isOngoing) Color(0xFF39A86B) else Color.Gray,
                                    fontWeight = FontWeight.ExtraBold,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }
                }

                // Nhúng widget Google Map Mini-map thực tế trực quan
                if (event.latitude != null && event.longitude != null) {
                    Spacer(Modifier.height(4.dp))
                    Text("Bản đồ vị trí:", fontWeight = FontWeight.Bold, color = Color(0xFFC43058), style = MaterialTheme.typography.labelLarge)
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .border(BorderStroke(1.dp, Color(0xFFFFEEF2)), RoundedCornerShape(18.dp))
                    ) {
                        GoogleMap(
                            modifier = Modifier.fillMaxSize(),
                            cameraPositionState = cameraPositionState
                        ) {
                            Marker(
                                state = MarkerState(position = eventLocation),
                                title = event.locationName,
                                snippet = event.address
                            )
                        }
                    }
                    
                    // Nút bấm mở Google Maps dẫn đường thực tế
                    Button(
                        onClick = {
                            val gmmIntentUri = Uri.parse("geo:${event.latitude},${event.longitude}?q=${Uri.encode(event.locationName + ", " + event.address)}")
                            val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri).apply {
                                setPackage("com.google.android.apps.maps")
                            }
                            if (mapIntent.resolveActivity(context.packageManager) != null) {
                                context.startActivity(mapIntent)
                            } else {
                                val webMapIntent = Intent(Intent.ACTION_VIEW, Uri.parse(event.googleMapsLink.ifBlank { "https://maps.google.com/?q=${event.latitude},${event.longitude}" }))
                                context.startActivity(webMapIntent)
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(44.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFEEF2), contentColor = Color(0xFFC43058)),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LocationOn, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Xem chỉ đường bằng Google Maps", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Text(event.description, color = Color(0xFF716B6F))
            }
        }
    }
}

@Composable
private fun BudgetPreviewCard(copy: Copy, vm: EventViewModel, eventId: Int) {
    val budget by vm.budgetFlow(eventId).collectAsState(initial = null)
    val expenses by vm.expensesFlow(eventId).collectAsState(initial = emptyList())
    var showAddDialog by remember { mutableStateOf(false) }
    
    val totalSpent = expenses.sumOf { it.amount }
    val isOverLimit = totalSpent > (budget?.warningLimit ?: Double.MAX_VALUE)
    val progress = if (budget == null || budget!!.estimatedBudget == 0.0) 0f else (totalSpent / budget!!.estimatedBudget).toFloat().coerceIn(0f, 1f)

    Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(copy.budget, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                IconButton(
                    onClick = { showAddDialog = true },
                    modifier = Modifier.background(Color(0xFFFFEEF2), CircleShape)
                ) {
                    Icon(Icons.Default.Add, null, tint = Color(0xFFC43058))
                }
            }
            Spacer(Modifier.height(12.dp))
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = if (isOverLimit) Color(0xFFD32F2F) else Color(0xFF9F2559))) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Dự toán", color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.labelSmall)
                            Text(formatMoney(budget?.estimatedBudget ?: 0.0), color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Thực chi", color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.labelSmall)
                            Text(formatMoney(totalSpent), color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                    
                    Spacer(Modifier.height(10.dp))
                    Text("Cảnh báo vượt chi: ${formatMoney(budget?.warningLimit ?: 0.0)}", color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.height(8.dp))
                    
                    // Thanh tiến độ chi tiêu trực quan
                    LinearProgressIndicator(
                        progress = progress,
                        color = if (isOverLimit) Color.Yellow else Color(0xFFFFB2C5),
                        trackColor = Color.White.copy(alpha = 0.2f),
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                    )
                }
            }
            
            if (isOverLimit) {
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Warning, null, tint = Color.Red, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Cảnh báo: Tổng chi phí thực tế đã vượt ngưỡng an toàn!", color = Color.Red, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                }
            }
            
            Spacer(Modifier.height(12.dp))
            Text("Danh sách chi tiết chi tiêu:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(6.dp))
            
            if (expenses.isEmpty()) {
                Text("Chưa có khoản chi nào được tạo.", color = Color.Gray, style = MaterialTheme.typography.labelMedium)
            } else {
                expenses.forEach {
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(it.expenseName, style = MaterialTheme.typography.labelMedium)
                        Text(formatMoney(it.amount), fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
    
    // Hộp thoại (Dialog) thêm khoản chi tiêu mới tương tác thực tế lưu Room
    if (showAddDialog) {
        var expenseName by remember { mutableStateOf("") }
        var expenseAmount by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Thêm chi phí thực tế") },
            confirmButton = {
                TextButton(
                    onClick = {
                        val amt = expenseAmount.toDoubleOrNull() ?: 0.0
                        if (expenseName.isNotBlank() && amt > 0.0) {
                            vm.addExpense(eventId, expenseName, amt)
                            showAddDialog = false
                        }
                    }
                ) {
                    Text("Lưu", color = Color(0xFFC43058))
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Hủy")
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = expenseName,
                        onValueChange = { expenseName = it },
                        label = { Text("Tên khoản chi (Ví dụ: Đặt cọc hoa tươi...)") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = expenseAmount,
                        onValueChange = { expenseAmount = it },
                        label = { Text("Số tiền chi tiêu (VNĐ)") },
                        singleLine = true
                    )
                }
            }
        )
    }
}

@Composable
private fun TaskPreviewCard(copy: Copy, vm: EventViewModel, eventId: Int) {
    val tasks by vm.tasksFlow(eventId).collectAsState(initial = emptyList())
    var showAddTaskDialog by remember { mutableStateOf(false) }
    
    Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(copy.tasks, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                IconButton(
                    onClick = { showAddTaskDialog = true },
                    modifier = Modifier.background(Color(0xFFFFEEF2), CircleShape)
                ) {
                    Icon(Icons.Default.Add, null, tint = Color(0xFFC43058))
                }
            }
            Spacer(Modifier.height(12.dp))
            if (tasks.isEmpty()) {
                EmptyMiniCard(copy.noTasksYet)
            } else {
                tasks.forEach { task ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Checkbox tương tác thực sự để cập nhật tiến độ công việc lưu Room DB
                        Checkbox(
                            checked = task.status == com.example.event_manager.data.TaskStatus.DONE,
                            onCheckedChange = { isChecked ->
                                val newStatus = if (isChecked) com.example.event_manager.data.TaskStatus.DONE else com.example.event_manager.data.TaskStatus.TODO
                                vm.updateTask(task.copy(status = newStatus))
                            }
                        )
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                text = task.taskName,
                                fontWeight = FontWeight.SemiBold,
                                style = if (task.status == com.example.event_manager.data.TaskStatus.DONE) 
                                    MaterialTheme.typography.bodyLarge.copy(textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough)
                                else MaterialTheme.typography.bodyLarge
                            )
                            Text("Hạn chót: ${formatDateTime(task.dueDate)}", color = Color(0xFF847D81), style = MaterialTheme.typography.labelSmall)
                        }
                        
                        // Icon thông báo trạng thái
                        if (task.status == com.example.event_manager.data.TaskStatus.DONE) {
                            Icon(Icons.Default.Check, null, tint = Color(0xFF39A86B), modifier = Modifier.size(18.dp))
                        } else {
                            Box(Modifier.size(8.dp).background(Color(0xFFF15A79), CircleShape))
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                }
            }
        }
    }
    
    // Hộp thoại (Dialog) thêm nhiệm vụ mới lưu Room cục bộ
    if (showAddTaskDialog) {
        var taskName by remember { mutableStateOf("") }
        var dueDays by remember { mutableStateOf("1") } // Số ngày chênh lệch tính từ hôm nay
        AlertDialog(
            onDismissRequest = { showAddTaskDialog = false },
            title = { Text("Thêm công việc chuẩn bị") },
            confirmButton = {
                TextButton(
                    onClick = {
                        val days = dueDays.toLongOrNull() ?: 1L
                        if (taskName.isNotBlank()) {
                            val dueDate = System.currentTimeMillis() + days * 86400000L
                            vm.addTask(eventId, taskName, dueDate)
                            showAddTaskDialog = false
                        }
                    }
                ) {
                    Text("Lưu", color = Color(0xFFC43058))
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddTaskDialog = false }) {
                    Text("Hủy")
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = taskName,
                        onValueChange = { taskName = it },
                        label = { Text("Nhiệm vụ cần chuẩn bị (Ví dụ: Treo băng rôn...)") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = dueDays,
                        onValueChange = { dueDays = it },
                        label = { Text("Số ngày hoàn thành (tính từ hôm nay)") },
                        singleLine = true
                    )
                }
            }
        )
    }
}

@Composable
private fun InvitationPreviewCard(copy: Copy, vm: EventViewModel, eventId: Int) {
    val invitations by vm.invitationsFlow(eventId).collectAsState(initial = emptyList())
    Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text(copy.inviteGuests, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            invitations.take(5).forEach {
                InvitationStatusRow(it, vm)
            }
        }
    }
}

@Composable
private fun EventRowCard(event: EventSummary, onClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).background(Color(0xFFFFE6EC), CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Event, null, tint = Color(0xFFC43058))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(event.eventName, fontWeight = FontWeight.SemiBold)
                Text(event.locationName, color = Color(0xFF827B7F), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(event.status.name, color = Color(0xFFC43058), fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun InvitationStatusRow(invite: InvitationWithGuest, vm: EventViewModel) {
    val tone = when (invite.responseStatus) {
        InvitationStatus.ACCEPTED -> Color(0xFF39A86B)
        InvitationStatus.DECLINED -> Color(0xFFE35B63)
        InvitationStatus.MAYBE -> Color(0xFFE5A524)
        InvitationStatus.PENDING -> Color(0xFF7D7A7E)
    }
    
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFDFE)),
        border = BorderStroke(1.dp, Color(0xFFFFEEF2)),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).background(Color(0xFFF7EEF1), CircleShape), contentAlignment = Alignment.Center) {
                Text(invite.guestName.take(1), fontWeight = FontWeight.Bold, color = Color(0xFFC43058))
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(invite.guestName, fontWeight = FontWeight.SemiBold)
                Text("Kênh: ${invite.channel.name}", color = Color(0xFF8A8487), style = MaterialTheme.typography.labelSmall)
            }
            
            // Trạng thái phản hồi hiện tại
            Text(
                text = when(invite.responseStatus) {
                    InvitationStatus.ACCEPTED -> "Tham gia"
                    InvitationStatus.DECLINED -> "Từ chối"
                    InvitationStatus.MAYBE -> "Có thể"
                    InvitationStatus.PENDING -> "Chờ phản hồi"
                },
                color = tone,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelMedium
            )
            Spacer(Modifier.width(10.dp))
            
            // Nút bấm tương tác RSVP nhanh lưu Room DB
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(
                    onClick = { vm.updateInvitation(invite.invitationId, InvitationStatus.ACCEPTED) },
                    modifier = Modifier.size(28.dp).background(Color(0xFFE8F5E9), CircleShape)
                ) {
                    Icon(Icons.Default.Check, null, tint = Color(0xFF39A86B), modifier = Modifier.size(16.dp))
                }
                IconButton(
                    onClick = { vm.updateInvitation(invite.invitationId, InvitationStatus.DECLINED) },
                    modifier = Modifier.size(28.dp).background(Color(0xFFFFEBEE), CircleShape)
                ) {
                    Icon(Icons.Default.Close, null, tint = Color(0xFFE35B63), modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
private fun FeedbackPreviewCard(copy: Copy, vm: EventViewModel, eventId: Int) {
    val feedbacks by vm.feedbacksFlow(eventId).collectAsState(initial = emptyList())
    var ratingState by remember { mutableStateOf(5) }
    var commentText by remember { mutableStateOf("") }
    
    val avgRating = if (feedbacks.isEmpty()) 0.0 else feedbacks.map { it.rating }.average()
    
    Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text("Đánh giá & Khảo sát", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            
            // Hiển thị điểm đánh giá trung bình mượt mà
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = String.format(java.util.Locale.getDefault(), "%.1f", avgRating),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFFC43058)
                )
                Spacer(Modifier.width(8.dp))
                Row {
                    for (i in 1..5) {
                        val isFilled = i <= avgRating.toInt()
                        Icon(
                            imageVector = if (isFilled) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = null,
                            tint = if (isFilled) Color(0xFFFFC107) else Color.LightGray,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                Spacer(Modifier.width(8.dp))
                Text("(${feedbacks.size} phản hồi)", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
            }
            
            Spacer(Modifier.height(12.dp))
            Divider(color = Color(0xFFFFEEF2))
            Spacer(Modifier.height(10.dp))
            
            // Form Khảo sát Tương tác thực tế
            Text("Gửi phản hồi của bạn:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(6.dp))
            
            // Các ngôi sao tương tác cho phép click chọn số sao đánh giá
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (i in 1..5) {
                    val isSelected = i <= ratingState
                    Icon(
                        imageVector = if (isSelected) Icons.Default.Star else Icons.Default.StarBorder,
                        contentDescription = null,
                        tint = if (isSelected) Color(0xFFFFC107) else Color.LightGray,
                        modifier = Modifier
                            .size(28.dp)
                            .clickable { ratingState = i }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = commentText,
                onValueChange = { commentText = it },
                label = { Text("Nhập ý kiến nhận xét của bạn...") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = false,
                maxLines = 3
            )
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = {
                    if (commentText.isNotBlank()) {
                        // Lưu trữ trực tiếp phản hồi mới vào SQLite qua ViewModel Room
                        vm.addFeedback(eventId, guestId = 1, rating = ratingState, comment = commentText)
                        commentText = "" // Xóa sạch form
                    }
                },
                modifier = Modifier.fillMaxWidth().height(42.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC43058)),
                shape = RoundedCornerShape(20.dp)
            ) {
                Text("Gửi đánh giá", fontWeight = FontWeight.Bold, color = Color.White)
            }
            
            // Danh sách hiển thị các bình luận đánh giá thu được từ Room
            if (feedbacks.isNotEmpty()) {
                Spacer(Modifier.height(16.dp))
                Text("Nhận xét từ khách mời:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.height(6.dp))
                feedbacks.take(3).forEach {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF9FA)),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        Column(Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Khách mời", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                                Row {
                                    for (s in 1..it.rating) {
                                        Icon(Icons.Default.Star, null, tint = Color(0xFFFFC107), modifier = Modifier.size(12.dp))
                                    }
                                }
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(it.comment, style = MaterialTheme.typography.bodyMedium, color = Color.DarkGray)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MessageRow(message: MessageLogEntity) {
    Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text(message.title, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(message.body, color = Color(0xFF7C777A), maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun ProfileAction(icon: ImageVector, title: String, subtitle: String? = null, onClick: () -> Unit) {
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Color(0xFFFFE6EC), CircleShape), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = Color(0xFFC43058))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                if (subtitle != null) Text(subtitle, color = Color(0xFF827B80))
            }
        }
    }
}

@Composable
private fun EmptyPanel(title: String, cta: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Card(shape = RoundedCornerShape(30.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.padding(22.dp)) {
            Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(72.dp).background(Color(0xFFFFEEF2), RoundedCornerShape(26.dp)), contentAlignment = Alignment.Center) { Text("💗") }
                Spacer(Modifier.height(16.dp))
                Text(title, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(cta, color = Color(0xFFC43058))
            }
        }
    }
}

@Composable
private fun EmptyMiniCard(text: String) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF5F7))) {
        Text(text, modifier = Modifier.fillMaxWidth().padding(16.dp), textAlign = TextAlign.Center)
    }
}

@Composable
private fun TinyMetric(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(
            Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFFC43058)
            )
            Text(label, color = Color(0xFF867F84))
        }
    }
}

@Composable
private fun StatusDot(label: String, value: Int) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value.toString(), color = Color.White, fontWeight = FontWeight.ExtraBold)
        Text(label, color = Color.White.copy(alpha = 0.85f))
    }
}

@Composable
private fun SoftActionChip(text: String, onClick: () -> Unit = {}) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEEF2)), modifier = Modifier.clickable(onClick = onClick)) {
        Text(text, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp), color = Color(0xFFC43058), fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun FilterPill(text: String, selected: Boolean, onClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFFC43058) else Color.White),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(text, modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp), color = if (selected) Color.White else Color(0xFF615B5F), fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun DetailLine(icon: ImageVector, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, modifier = Modifier.size(16.dp), tint = Color(0xFFC43058))
        Spacer(Modifier.width(8.dp))
        Text(text, color = Color(0xFF726B6E))
    }
}

@Composable
private fun CenterLineText(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Divider(modifier = Modifier.weight(1f), color = Color(0xFFE2DADD))
        Text(text, modifier = Modifier.padding(horizontal = 10.dp), color = Color(0xFF91898D), style = MaterialTheme.typography.labelSmall)
        Divider(modifier = Modifier.weight(1f), color = Color(0xFFE2DADD))
    }
}

@Composable
private fun SocialButton(text: String, modifier: Modifier = Modifier, filled: Boolean = false) {
    val bg = if (filled) Color(0xFF2E78F6) else Color(0xFFF5F1F2)
    val fg = if (filled) Color.White else Color(0xFF302C2E)
    Surface(shape = RoundedCornerShape(18.dp), color = bg, modifier = modifier.height(48.dp), border = if (filled) null else BorderStroke(1.dp, Color(0xFFE6DEE1))) {
        Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Text(if (text == "Google") "G" else "f", color = fg, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(8.dp))
            Text(text, color = fg, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun PrimaryPinkButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(54.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
        contentPadding = PaddingValues()
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.horizontalGradient(listOf(Color(0xFFF7748F), Color(0xFFC12E57))), RoundedCornerShape(28.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(text, color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun AuthTopBar(onBack: () -> Unit, title: String, action: String, onAction: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color(0xFFC43058)) }
        Text(title, color = Color(0xFFE5335A), fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.weight(1f))
        Text(action, color = Color(0xFFE85272), fontWeight = FontWeight.Bold, modifier = Modifier.clickable(onClick = onAction))
    }
}

@Composable
private fun AuthField(label: String, value: String, onValueChange: (String) -> Unit, icon: ImageVector, placeholder: String) {
    Column {
        Text(label, color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        androidx.compose.material3.OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            placeholder = { Text(placeholder, color = Color.White.copy(alpha = 0.35f)) },
            leadingIcon = { Icon(icon, null, tint = Color.White.copy(alpha = 0.6f)) },
            singleLine = true,
            colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedBorderColor = Color(0xFFFF4B72),
                unfocusedBorderColor = Color.White.copy(alpha = 0.15f),
                focusedContainerColor = Color.White.copy(alpha = 0.04f),
                unfocusedContainerColor = Color.White.copy(alpha = 0.04f),
                focusedLabelColor = Color(0xFFFF4B72),
                unfocusedLabelColor = Color.White.copy(alpha = 0.5f)
            )
        )
    }
}

@Composable
private fun PasswordField(label: String, value: String, onValueChange: (String) -> Unit, trailingText: String? = null, onTrailingClick: (() -> Unit)? = null) {
    var visible by remember { mutableStateOf(false) }
    Column {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text(label, color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            if (trailingText != null && onTrailingClick != null) {
                Text(trailingText, color = Color(0xFFFF4B72), fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.labelMedium, modifier = Modifier.clickable(onClick = onTrailingClick))
            }
        }
        Spacer(Modifier.height(8.dp))
        androidx.compose.material3.OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            placeholder = { Text("••••••••", color = Color.White.copy(alpha = 0.35f)) },
            leadingIcon = { Icon(Icons.Default.Lock, null, tint = Color.White.copy(alpha = 0.6f)) },
            trailingIcon = {
                IconButton(onClick = { visible = !visible }) {
                    Icon(if (visible) Icons.Default.Visibility else Icons.Default.VisibilityOff, null, tint = Color.White.copy(alpha = 0.6f))
                }
            },
            visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
            singleLine = true,
            colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedBorderColor = Color(0xFFFF4B72),
                unfocusedBorderColor = Color.White.copy(alpha = 0.15f),
                focusedContainerColor = Color.White.copy(alpha = 0.04f),
                unfocusedContainerColor = Color.White.copy(alpha = 0.04f),
                focusedLabelColor = Color(0xFFFF4B72),
                unfocusedLabelColor = Color.White.copy(alpha = 0.5f)
            )
        )
    }
}

@Composable
private fun AddGuestDialog(copy: Copy, onDismiss: () -> Unit, onSave: (String, String, String) -> Unit) {
    var name by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = { onSave(name, email, phone) }) { Text(copy.addGuest, color = Color(0xFFC43058)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        title = { Text(copy.addGuest) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text(copy.fullName) })
                OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text(copy.email) })
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone") })
            }
        }
    )
}

private fun parseTimeToMillis(eventStartMillis: Long, timeStr: String): Long {
    return try {
        val parts = timeStr.trim().split(":")
        val hours = parts[0].toInt()
        val minutes = parts[1].toInt()
        val calendar = java.util.Calendar.getInstance().apply {
            timeInMillis = eventStartMillis
            set(java.util.Calendar.HOUR_OF_DAY, hours)
            set(java.util.Calendar.MINUTE, minutes)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
        }
        calendar.timeInMillis
    } catch (e: Exception) {
        eventStartMillis
    }
}

@Composable
private fun TimelinePreviewCard(copy: Copy, vm: EventViewModel, event: EventSummary) {
    val eventId = event.eventId
    val schedules by vm.schedulesFlow(eventId).collectAsState(initial = emptyList())
    var showAddScheduleDialog by remember { mutableStateOf(false) }

    Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Kịch bản Timeline", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                IconButton(
                    onClick = { showAddScheduleDialog = true },
                    modifier = Modifier.background(Color(0xFFFFEEF2), CircleShape)
                ) {
                    Icon(Icons.Default.Add, null, tint = Color(0xFFC43058))
                }
            }
            Spacer(Modifier.height(12.dp))
            
            if (schedules.isEmpty()) {
                EmptyMiniCard("Chưa lập lịch trình kịch bản cho sự kiện này.")
            } else {
                schedules.forEachIndexed { index, schedule ->
                    val currentTime = System.currentTimeMillis()
                    val isPast = currentTime > schedule.endTime
                    val isOngoing = currentTime in schedule.startTime..schedule.endTime
                    val isUpcoming = currentTime < schedule.startTime

                    val dotColor = when {
                        isOngoing -> Color(0xFF39A86B)
                        isUpcoming -> Color(0xFFFFC107)
                        else -> Color.LightGray
                    }
                    
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier
                                    .size(14.dp)
                                    .background(dotColor, CircleShape)
                            )
                            if (index < schedules.size - 1) {
                                Box(
                                    modifier = Modifier
                                        .width(2.dp)
                                        .height(50.dp)
                                        .background(Color(0xFFFFEEF2))
                                )
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                text = schedule.activityName,
                                fontWeight = FontWeight.Bold,
                                color = if (isPast) Color.Gray else Color.Black,
                                style = if (isPast) 
                                    MaterialTheme.typography.bodyLarge.copy(textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough)
                                else MaterialTheme.typography.bodyLarge
                            )
                            Spacer(Modifier.height(2.dp))
                            
                            val startFormat = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(schedule.startTime))
                            val endFormat = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(schedule.endTime))
                            
                            Text(
                                text = "$startFormat - $endFormat",
                                color = Color.Gray,
                                style = MaterialTheme.typography.labelSmall
                            )
                            
                            // Hiển thị đếm ngược thời gian động cho hoạt động kịch bản đang diễn ra
                            if (isOngoing) {
                                val remainingMins = (schedule.endTime - currentTime) / (60 * 1000)
                                Spacer(Modifier.height(4.dp))
                                Box(
                                    modifier = Modifier
                                        .background(Color(0xFFE8F5E9), RoundedCornerShape(8.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "🟢 Đang chạy (Còn lại khoảng $remainingMins phút)",
                                        color = Color(0xFF2E7D32),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            } else if (isUpcoming) {
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = "🟡 Sắp diễn ra",
                                    color = Color(0xFFF57F17),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            } else {
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = "⚫ Đã kết thúc",
                                    color = Color.Gray,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Dialog thêm hoạt động kịch bản mới
    if (showAddScheduleDialog) {
        var activityName by remember { mutableStateOf("") }
        var startHour by remember { mutableStateOf("08:00") }
        var endHour by remember { mutableStateOf("09:30") }
        
        AlertDialog(
            onDismissRequest = { showAddScheduleDialog = false },
            title = { Text("Thêm hoạt động kịch bản") },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (activityName.isNotBlank() && startHour.contains(":") && endHour.contains(":")) {
                            val start = parseTimeToMillis(event.startDatetime, startHour)
                            val end = parseTimeToMillis(event.startDatetime, endHour)
                            vm.addSchedule(eventId, activityName, start, end)
                            showAddScheduleDialog = false
                        }
                    }
                ) {
                    Text("Lưu", color = Color(0xFFC43058))
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddScheduleDialog = false }) {
                    Text("Hủy")
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = activityName,
                        onValueChange = { activityName = it },
                        label = { Text("Tên hoạt động (Ví dụ: Đón khách...)") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = startHour,
                        onValueChange = { startHour = it },
                        label = { Text("Giờ bắt đầu (Ví dụ: 08:30)") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = endHour,
                        onValueChange = { endHour = it },
                        label = { Text("Giờ kết thúc (Ví dụ: 10:00)") },
                        singleLine = true
                    )
                }
            }
        )
    }
}

@Composable
private fun AddEventDialog(
    copy: Copy,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String, Double, Double) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var locationName by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var latText by remember { mutableStateOf("10.7731") }
    var lngText by remember { mutableStateOf("106.7042") }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                onClick = {
                    if (title.isNotBlank() && locationName.isNotBlank() && address.isNotBlank()) {
                        val lat = latText.toDoubleOrNull() ?: 10.7731
                        val lng = lngText.toDoubleOrNull() ?: 106.7042
                        onSave(title, desc, locationName, address, lat, lng)
                    }
                }
            ) {
                Text("Lưu sự kiện", color = Color(0xFFC43058))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Hủy") }
        },
        title = { Text("Tạo sự kiện mới") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Tên sự kiện") }, singleLine = true)
                OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Mô tả chi tiết") })
                OutlinedTextField(value = locationName, onValueChange = { locationName = it }, label = { Text("Tên địa điểm (GEM Center,...)") }, singleLine = true)
                OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Địa chỉ chi tiết") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = latText, onValueChange = { latText = it }, label = { Text("Vĩ độ (Lat)") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = lngText, onValueChange = { lngText = it }, label = { Text("Kinh độ (Lng)") }, modifier = Modifier.weight(1f), singleLine = true)
                }
            }
        }
    )
}

@Composable
private fun PhoneFrame(content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF7F3F5))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
        ) {
            content()
        }
    }
}
