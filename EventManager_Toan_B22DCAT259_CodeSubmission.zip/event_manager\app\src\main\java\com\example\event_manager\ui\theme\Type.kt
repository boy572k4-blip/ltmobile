package com.example.event_manager.ui.theme

import androidx.compose.material3.Typography

val Typography = Typography()
