# Checklist upload source code

## File/thư mục cần có

- `app/src/main/java/com/example/event_manager/data/`
- `app/src/main/java/com/example/event_manager/data/remote/`
- `app/src/main/java/com/example/event_manager/services/`
- `app/src/main/java/com/example/event_manager/ui/`
- `app/src/main/java/com/example/event_manager/util/`
- `app/src/main/AndroidManifest.xml`
- `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`
- `gradlew`, `gradlew.bat`, `gradle/wrapper/`
- `README.md`, `PERSONAL_CONTRIBUTION.md`, `local.properties.example`

## File/thư mục không upload

- `.gradle/`
- `.idea/`
- `build/`
- `app/build/`
- `local.properties`

## Lệnh upload GitHub

```bash
git init
git add .
git commit -m "Hoan thien module Event Manager"
git branch -M main
git remote add origin https://github.com/<username>/<repo-name>.git
git push -u origin main
```

Sau khi upload, copy link repository GitHub vào báo cáo hoặc phần nộp bài.
